package com.resources.model;

public class Comment {
	public int id;
	public String comment;
	
	
	
	//Constructors:
	
	public Comment(int id, String comment) {
		super();
		this.id = id;
		this.comment = comment;
	}

	public Comment() {
		super();
	}
	
	//Getters and setters:
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	//ToString:
	@Override
	public String toString() {
		return "Comment [id=" + id + ", comment=" + comment + "]";
	}
	
	
	
	
	

}
