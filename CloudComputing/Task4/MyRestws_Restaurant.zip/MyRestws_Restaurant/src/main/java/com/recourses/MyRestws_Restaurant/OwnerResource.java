package com.recourses.MyRestws_Restaurant;



import java.util.ArrayList;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import org.eclipse.yasson.internal.serializer.IntegerTypeDeserializer;

import com.resources.model.Owner;
import com.resources.model.OwnerService;

@Path("/owners")
public class OwnerResource 
{
	OwnerService ownerService = new OwnerService();
	
	@PermitAll
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	
	public ArrayList<Owner> getAllOwners()
	{
		return (ArrayList<Owner>) ownerService.getAllOwners();
	}
	
	@PermitAll
	@GET
	@Path("{ownerId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getOwnerById(@PathParam("ownerId") int ownerId)
	{
		if(ownerId <= 0 || ownerService.getOwner(ownerId) == null)
		{
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.status(Status.FOUND).entity(ownerService.getOwner(ownerId)).build();
	}

	//**********************************************************
	@RolesAllowed("ADMIN")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addOwner(Owner owner)
	{
		if(owner.getName().isEmpty())
			return Response.status(Status.BAD_REQUEST).build();
		return Response.status(Status.CREATED).entity(ownerService.addOwner(owner)).build();
	}
	
	//**********************************************
	@RolesAllowed("ADMIN")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{ownerId}")
	public Response updateOwner(@PathParam("ownerId") int id,Owner owner)
	{
		//owner.setId(ownerId);
		if(ownerService.getOwner(id)!= null)
			return Response.status(Status.OK)
					.entity(ownerService.updateOwner(id,owner)).build();
		
		else
			return Response.status(Status.NOT_FOUND).entity("not such info found").build();
	}
	//PREVIOUS:
	/*@PUT
	@Path("/{ownerId}") 
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Owner updateOwner(@PathParam("ownerId") int id, Owner owner){
		//owner.setId(id);
		return ownerService.updateOwner(owner);
		
	}*/
	//***********************************
	@RolesAllowed("ADMIN")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{ownerId}")
	public Response deleteOwner(@Context UriInfo info,@PathParam("ownerId") int id)
	{
		if(ownerService.getOwner(Integer.parseInt(info.getPathParameters().getFirst("ownerId"))) != null)
		{
			//System.out.println(Integer.parseInt(info.getPathParameters().getFirst("ownerId")));
			return Response.status(Status.OK).entity(ownerService.removeOwner(id)).build();
		}
		return Response.status(Status.NOT_FOUND).build();
	}
	/*@DELETE
	@Path("/{ownerId}") 
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteOwner(@PathParam("ownerId") String name){
		ownerService.removeOwner(name);
	}*/

}
