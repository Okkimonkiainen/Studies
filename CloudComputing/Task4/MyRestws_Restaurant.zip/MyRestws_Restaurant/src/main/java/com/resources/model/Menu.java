package com.resources.model;

//import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement
public class Menu {
	public int id;
	public String item;
	public String description;
	public double price;
	
	//Constructors
	public Menu() {
		super();
	}
	
	public Menu(int id, String item, String description, double price) {
		super();
		this.id=id;
		this.item = item;
		this.description = description;
		this.price = price;
	}

	//Setters and getters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	
	//Methods
	@Override
	public String toString() {
		return "Menu [id=" + id + "item=" + item + ", description=" + description + ", price=" + price + "]";
	}
	
	
	
	

	
	
	
	
	
	
	
}
