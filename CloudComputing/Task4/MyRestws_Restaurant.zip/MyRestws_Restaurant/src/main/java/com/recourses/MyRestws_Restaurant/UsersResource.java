package com.recourses.MyRestws_Restaurant;

import java.net.URI;
import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;

import com.resources.model.Restaurant;
import com.resources.model.User;
import com.resources.model.UserService;

@Path("/users")

public class UsersResource {

	static UserService userService = new UserService();
	
	
	public static UserService getUserService() {
		return userService;
	}

	@RolesAllowed("admin")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUsers()
	{	
		return	Response.status(Status.FOUND)
				.entity(userService.getUsers2())
				.build();	
	}
	
	@PermitAll
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addUser(User user){
			return Response.status(Status.CREATED)
			        .entity(userService.addUser(user))
			        .build();
					
		}
	
	@RolesAllowed("admin")
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("{userId}")
	public Response updateUser(@PathParam("userId") int id,User user)
	{	
		if(user.getRole().size() == 0)
			return Response.status(Status.BAD_REQUEST).entity("the role of user must be determined").build();
		
		return	Response.status(Status.OK)
				.entity(userService.updateUser(id,user))
				.build();	
	}
	
	
	@RolesAllowed("admin")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("{userId}")
	
	public Response deleteUser(@PathParam("userId") int id,User user)
	{
		System.out.println(userService.getUsers2());
		return	Response.status(Status.OK)
				.entity(userService.removeUser(id,user))
				.build();	
	}

	
	
	
	/*@GET
	@Produces(MediaType.APPLICATION_JSON)
	@RolesAllowed("admin")
	public List<User> getUser()  {
		List<User> users = usersService.getUsers();
		if (!users.isEmpty()) { 
		return users;
		}
		return null;
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@PermitAll
	public Response newUser(User user, @Context UriInfo uriInfo) {
		User addNewUser = usersService.newUser(user);

		String newId = String.valueOf(addNewUser.getId());
		URI url = uriInfo.getAbsolutePathBuilder().path(newId).build();
		return Response.created(url).entity(addNewUser).build();
	}*/

	

}
