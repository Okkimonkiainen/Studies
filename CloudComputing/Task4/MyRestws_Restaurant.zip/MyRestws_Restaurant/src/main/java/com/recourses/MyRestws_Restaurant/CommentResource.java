package com.recourses.MyRestws_Restaurant;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;

import com.resources.model.Comment;
import com.resources.model.CommentService;
import com.resources.model.Menu;
import com.resources.model.MenuService;
import com.resources.model.RestaurantService;

//@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CommentResource {
	
	private CommentService commentService = new CommentService();
	
		
	//@PermitAll
	@PermitAll
	@GET
	@Path("{commentId}")
	public Response getComments(@PathParam("restaurantId") int restaurantId,
			@PathParam("commentId") int commentId)
	{
		System.out.println("coId : "+commentId + "resId : "+restaurantId);
		if(commentId > 0)
			return Response.status(Status.FOUND)
					.entity(commentService.getAllCommentsForId(commentId, restaurantId)).build();
		return Response.status(Status.NOT_FOUND).build();

	}
	@PermitAll
	@GET
	public Response getAll(@PathParam("restaurantId") int restaurantId)
	{
		
		return Response.status(Status.FOUND)
				.entity(commentService.getAllComments(restaurantId))
			    .build();
	}
	
	
	@RolesAllowed("USER")
	@POST
	public Response addComment(@PathParam("restaurantId") int restaurantId, Comment comment){
		return Response.status(Status.CREATED)
		        .entity(commentService.addComment(restaurantId, comment))
		        .build();
	}
	
/*	@PUT
	public Response updateComment(@Context UriInfo info, Comment comment)
	{
		int restaurantId = Integer.parseInt(info.getPathParameters().getFirst("restaurantId"));		
		int commentId = Integer.parseInt(info.getPathParameters().getFirst("commentId"));
		System.out.println("restaurantId "+restaurantId+"\n commentId"+commentId);
		/*if(comment.getComment().isEmpty()){
			return Response.status(Status.BAD_REQUEST).entity("no comment provided").build();
		}*/
		
	/*	if(commentService.getAllCommentsForId(commentId, restaurantId) == null){
			return Response.status(Status.NOT_FOUND).build();
		}*/
		
	/*	comment.setId(commentId);
		return Response.status(Status.OK)
		        .entity(commentService.updateComment(restaurantId,commentId, comment))
		        .build();		
		
	}*/
	@RolesAllowed("ADMIN")
	@PUT
	@Path("{commentId}")
	public Response updateComment(@PathParam("restaurantId") int restaurantId, 
			@PathParam("commentId") int commentId, Comment comment)
	{
		comment.setId(commentId);
		return Response.status(Status.OK)
		        .entity(commentService.updateComment(restaurantId,commentId, comment))
		        .build();	
	}
	
	
	
	/*@DELETE
	public Response removeComment(@Context UriInfo info)
	{

		int restaurantId = Integer.parseInt(info.getPathParameters().getFirst("restaurantId"));		
		int commentId = Integer.parseInt(info.getPathParameters().getFirst("commentId"));
		System.out.println("restaurantId "+restaurantId+"\n commentId"+commentId);
		
		if(commentService.getAllCommentsForId(commentId, restaurantId) == null){
			return Response.status(Status.NOT_FOUND).build();
		}		

		return Response.status(Status.OK)
				.entity(commentService.removeComment(restaurantId, commentId))
				.build();
	
	}*/
	@RolesAllowed("ADMIN")
	@DELETE
	@Path("{commentId}")
	public Response removeComment(@PathParam("restaurantId") int restaurantId,
			@PathParam("commentId") int commentId)
	{

		System.out.println("restaurantId "+restaurantId+"\n commentId "+commentId);
		return Response.status(Status.OK)
				.entity(commentService.removeComment(restaurantId, commentId))
				.build();
	
	}
}
