package com.resources.model;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;



//@XmlAccessorType (XmlAccessType.FIELD)
@XmlRootElement
public class Restaurant {


	public int id;
	public int ownerId;
	public String name;
	public String address;
	public String phone;
	public int postalcode;
	private HashMap<Integer, Menu> menus = new HashMap<>();
	private HashMap<Integer, Comment> comments = new HashMap<>();
	//private List<Link> links = new ArrayList<>();
	private ArrayList<Link> links = new ArrayList<>();
	//public ArrayList<Menu> menu_list =new ArrayList<Menu>();
 
	
	//Constructors
	public Restaurant() {
		super();
	}
	
	/*public Restaurant(ArrayList<Menu> menu_list) {
		super();
		this.menu_list = menu_list;
	}*/
	
	public Restaurant(int id, int ownerId,String name, String address, String phone, int postalcode) {
		super();
		this.id = id;
		this.ownerId=ownerId;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.postalcode=postalcode;
	}
	
	
	//Methods:
	
/*	public void addMenuToRestaurant(Menu m){
		menu_list.add(m); 
	}*/
	
	
//Getters and setters:
	//For postalcode:
	public int getPostalcode() {
		return postalcode;
	}

	public void setPostalcode(int postalcode) {
		this.postalcode = postalcode;
	}
	
	
	public int getId() {
		return id;
	}
	

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	/*public ArrayList<Menu> getMenu_list() {
		return menu_list;
	}*/

	/*public void setMenu_list(ArrayList<Menu> menu_list) {
		this.menu_list = menu_list;
	}*/
	
	
	@Override
	public String toString() {
		return "Restaurant [id=" + id + ", name=" + name + ", address=" + address + ", postalcode " +postalcode+ ", phone=" + phone + ", menu_list="
				 + "]"; //+ menu_list
	}
	
	
	@XmlTransient
	public Map<Integer, Menu> getMenus(){
		return menus;
	}
	
	public void setMenus(HashMap<Integer, Menu> menus){
		this.menus= menus;
	}
	
	public Map<Integer, Comment> getComments(){
		return comments;
	}
	
	public void setComments(HashMap<Integer, Comment> comments){
		this.comments= comments;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public ArrayList<Link> getLinks() {
		return links;
	}

	public void setLinks(ArrayList<Link> links) {
		this.links = links;
	}
	
	
	public void addLink(String url, String rel){
		Link link = new Link();
		link.setLink(url);
		link.setRel(rel);
		links.add(link);
	}
	
	
}
