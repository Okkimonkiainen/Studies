package com.recourses.MyRestws_Restaurant;

import java.net.URI;
//import java.awt.PageAttributes.MediaType;
import java.util.ArrayList;

import java.util.List;

import javax.ws.rs.PathParam;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import com.recourses.Database.DBclass;
import com.resources.model.Restaurant;

import com.resources.model.RestaurantService;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
@Path("/restaurants")
public class RestaurantResource 
{

	

	RestaurantService restaurantService = new RestaurantService();
	
	@PermitAll
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getRestaurants(@QueryParam("postalcode") int postalcode)
	{
		//Response.status(Status.FOUND)
		//.entity(restaurantService.getAllRestaurants())
		//.build();
		if(postalcode >0){
			return Response.status(Status.FOUND)
			.entity(restaurantService.getAllRestaurantsForPostalcode(postalcode))
			.build();
		}
		if(postalcode<0){
			return Response.status(Status.NOT_FOUND).build();
		}
		
		return	Response.status(Status.FOUND)
				.entity(restaurantService.getAllRestaurants())
				.build();	
	}
	
	@PermitAll
	@GET
	@Path("{restaurantId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response test(@Context UriInfo uriInfo, @PathParam("restaurantId") int restaurantId)
	{
		if(restaurantId > restaurantService.getAllRestaurants().size())
			return Response.status(Status.NOT_FOUND).build();
		
		Restaurant restaurant = restaurantService.getRestaurant(restaurantId);
		//Link for owner:
		restaurant.addLink(getUriForOwner(uriInfo,restaurant), "owner"); 
		
		return Response.status(Status.FOUND)
				.entity(restaurant) 
				.build();
	
	}
	
	
	private String getUriForOwner(UriInfo uriInfo, Restaurant restaurant) {
		String value = String.valueOf(restaurant.getOwnerId());
		URI uri = uriInfo.getBaseUriBuilder().path(OwnerResource.class).path(value).build();
		return uri.toString();
	}

	@RolesAllowed("admin")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addRestaurant(Restaurant restaurant){
		
		if(restaurant.getName().isEmpty() || restaurant.getAddress().isEmpty()){
			return Response.status(Status.BAD_REQUEST).build();
		}
		else{
			return Response.status(Status.CREATED)
			        .entity(restaurantService.addRestaurant(restaurant))
			        .build();
					
		}
	}
	
	@RolesAllowed("admin")
	@PUT
	@Path("/{restaurantId}") 
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateRestaurant(@PathParam("restaurantId") int restaurantId,Restaurant restaurant){

		if(restaurant.getAddress().isEmpty() || restaurant.getName().isEmpty() || restaurant.postalcode<0){
			return Response.status(Status.BAD_REQUEST).build();
		}
		
		restaurant.setId(restaurantId);
		return Response.status(Status.OK)
				   .entity(restaurantService.updateRestaurant(restaurant))
				   .build();
		
		
	}
	
	@RolesAllowed("admin")
	@DELETE
	@Path("/{restaurantId}") 
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteMessage(@PathParam("restaurantId") int id){
			return Response.status(Status.OK)
					.entity(restaurantService.removeRestaurant(id))
					.build();
		}
	
	

	//Subclass:
	@Path("/{restaurantId}/menu")
	public MenuResource getMenuResource(){
		return new MenuResource();
		
	}
	
	//Subclass:
	@Path("/{restaurantId}/comment")
	public CommentResource getCommentResource(){
		return new CommentResource();
		
	}
	
	
}


/*
@Path("/restaurants")
public class RestaurantResource 
{
	
	//RestaurantApp restauApp = new RestaurantApp();
	RestaurantService restaurantService = new RestaurantService();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getRestaurants(	@Context UriInfo uriInfo, @QueryParam("postalcode") int postalcode,
											@QueryParam("start") int start,
											@QueryParam("size") int size,
											@QueryParam("id") int id)
	{
		//Response.status(Status.FOUND)
		//.entity(restaurantService.getAllRestaurants())
		//.build();
		if(postalcode >0){
			return Response.status(Status.FOUND)
			.entity(restaurantService.getAllRestaurantsForPostalcode(postalcode))
			.build();
		}
		//start=1 and size 1 --> we'll get the second restaurant
		if(start >=0 && size >0){
			return Response.status(Status.FOUND)
					.entity(restaurantService.getAllRestaurantsPaginated(start, size))
					.build();
		}
		if(id>0){
			Restaurant restaurant = restaurantService.getRestaurant(id);
			//Link for owner:
			restaurant.addLink(getUriForOwner(uriInfo,restaurant), "owner"); 
			
			return Response.status(Status.FOUND)
					.entity(restaurant) 
					.build();
			
		}
		if(postalcode<0 || id<0){
			return Response.status(Status.NOT_FOUND).build();
		}
		
		return	Response.status(Status.FOUND)
				.entity(restaurantService.getAllRestaurants())
				.build();	
	}
	private String getUriForOwner(UriInfo uriInfo, Restaurant restaurant) {
		String value = String.valueOf(restaurant.getOwnerId());
		URI uri = uriInfo.getBaseUriBuilder().path(OwnerResource.class).path(value).build();
		return uri.toString();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addRestaurant(Restaurant restaurant){
		
		if(restaurant.getName().isEmpty() || restaurant.getAddress().isEmpty()){
			return Response.status(Status.BAD_REQUEST).build();
		}
		else{
			return Response.status(Status.CREATED)
			        .entity(restaurantService.addRestaurant(restaurant))
			        .build();
					
		}
	}
	
	@PUT
	//@Path("/{restaurantId}") 
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateRestaurant(@QueryParam("restaurantId") int id, Restaurant restaurant){
		if(id<=0){
			return Response.status(Status.NOT_FOUND).build();
		}
		if(restaurant.getAddress().isEmpty() || restaurant.getName().isEmpty() || restaurant.postalcode<0){
			return Response.status(Status.BAD_REQUEST).build();
		}
		
		restaurant.setId(id);
		return Response.status(Status.OK)
				   .entity(restaurantService.updateRestaurant(restaurant))
				   .build();
		
	}
	
	@DELETE
	//@Path("/{restaurantId}") 
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteMessage(@QueryParam("restaurantId") int id){
		if(id<=0){
			return Response.status(Status.NOT_FOUND).build();
		}
		else{
			return Response.status(Status.OK)
					.entity(restaurantService.removeRestaurant(id))
					.build();
		}
	}
	

	//Subclass:
	@Path("/{restaurantId}/menu")
	public MenuResource getMenuResource(){
		return new MenuResource();
		
	}
	
	//Subclass:
	@Path("/{restaurantId}/comment")
	public CommentResource getCommentResource(){
		return new CommentResource();
		
	}
	
	//RestaurantApp restauApp = new RestaurantApp();
/*	RestaurantService restaurantService = new RestaurantService();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getRestaurants(	@QueryParam("postalcode") int postalcode,
											@QueryParam("start") int start,
											@QueryParam("size") int size,
											@QueryParam("id") int id)
	{
		Response.status(Status.FOUND)
		.entity(restaurantService.getAllRestaurants())
		.build();
		if(postalcode >0){
			return Response.status(Status.FOUND)
			.entity(restaurantService.getAllRestaurantsForPostalcode(postalcode))
			.build();
		}
		//start=1 and size 1 --> we'll get the second restaurant
		if(start >=0 && size >0){
			return Response.status(Status.FOUND)
					.entity(restaurantService.getAllRestaurantsPaginated(start, size))
					.build();
		}
		if(id>0){
			return Response.status(Status.FOUND)
					.entity(restaurantService.getAllRestaurantsForId(id))
					.build();
			
		}
		
		return	Response.status(Status.FOUND)
				.entity(restaurantService.getAllRestaurants())
				.build();	
	}
	
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addRestaurant(Restaurant restaurant){
		
		return Response.status(Status.CREATED)
		        .entity(restaurantService.addRestaurant(restaurant))
		        .build();
	}
	
	@PUT
	//@Path("/{restaurantId}") 
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateRestaurant(@QueryParam("restaurantId") int id, Restaurant restaurant){
		restaurant.setId(id);
		
		return Response.status(Status.ACCEPTED)
				   .entity(restaurantService.updateRestaurant(restaurant))
				   .build();
		
	}
	
	@DELETE
	//@Path("/{restaurantId}") 
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteMessage(@QueryParam("restaurantId") int id){
		return Response.status(Status.GONE)
		.entity(restaurantService.removeRestaurant(id))
		.build();
	}
	

	//Subclass:
	@Path("/{restaurantId}/menu")
	public MenuResource getMenuResource(){
		return new MenuResource();
		
	}
	
	//Subclass:
	@Path("/{restaurantId}/comment")
	public CommentResource getCommentResource(){
		return new CommentResource();
		
	}
	*/
	
//}
