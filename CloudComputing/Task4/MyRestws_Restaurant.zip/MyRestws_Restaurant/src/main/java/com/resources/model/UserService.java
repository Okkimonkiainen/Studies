package com.resources.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.IntStream;

import javax.inject.Singleton;

import com.recourses.Database.DBclass;
@Singleton
public class UserService {

	//private List<User> users;
	private int userId=0;
	private HashMap<Integer, User> users2 =DBclass.getUsers();
	private List<String> nonces;	

	/*public UserService() {
		this.users = new ArrayList<User>();
	}*/
	
	
	//Users LIST:
	
//	public UserService() {
//		this.users = new ArrayList<User>();
//		this.nonces = new ArrayList<String>();
//	}
//	

	

	

	

	public UserService() {
		this.users2 = new HashMap<Integer,User>();
		this.nonces = new ArrayList<String>();
	}

	
	



	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId) {
		this.userId = userId;
	}



	public HashMap<Integer, User> getUsers2() {
		return users2;
	}



	public void setUsers2(HashMap<Integer, User> users2) {
		this.users2 = users2;
	}



	public List<String> getNonces() {
		return nonces;
	}



	public void setNonces(List<String> nonces) {
		this.nonces = nonces;
	}



	public boolean checkCredentilas(String username, String password) {
//		IntStream s=username.chars(); ;
//		CharSequence p =(CharSequence) password.chars();
		for (int i = 0; i < users2.size(); i++) {
//			System.out.println(users2.get(i).getLogin().contains(username));
//			if (users2.get(i).getLogin().contains((CharSequence) s) && (users2.get(i).getLogin().contains(p)))
//					{
//				return true;
//			}
//			if (users2.get(i).getLogin())&&(users2.get(i).getLogin().compareTo(password)) 
			
		if ((users2.get(i).getLogin().contentEquals(username)) && ((users2.get(i).getLogin().contentEquals(password)))) {
				return true;
		}
		}
		return false;
	}
	
	public User getCertainUser(int id) {
	
		for (int i = 0; i < users2.size(); i++) {
			if (users2.get(i).getId() == id)
				return users2.get(i);
		}
		return null;
	}
	
	public User getUser(String username) {
		System.out.println(users2.size());
		for (int i = 0; i < users2.size(); i++) {
			if (users2.get(i).getLogin().equals(username)) {
				System.out.println(users2.get(i));
				return users2.get(i);
			}
		}
		return null;
	}
	
	public User addUser(User user) {
		user.setId(userId);
		if (users2.size() == 0){
			user.addRole("admin");
			}
		else{
		user.addRole("user");
		}
		userId++;
		users2.put((users2.size()), user);
		return user;
		} 
	
	public void addNonce(String nonce) {
		nonces.add(nonce);
	}
	
	public void deleteNonce(String nonce) {
		nonces.remove(nonce);
	}






	public User updateUser(int id,User user){
		user.setId(id);
		if(user.getId()<=0){
			return null;
			
		}
		//user.setId(id);
		users2.put(user.getId(), user);
		return user;
	}
	
	public User removeUser(int id,User user){
//		System.out.println(id);
		//restaurant.setId(restaurants.size()-1); --> Something like this to remove from the amount of restaurants
		
		        users2.remove(id);
				System.out.println(users2);
				return user;
		}
		
	
		
		
	




	
		
	}



	
		

