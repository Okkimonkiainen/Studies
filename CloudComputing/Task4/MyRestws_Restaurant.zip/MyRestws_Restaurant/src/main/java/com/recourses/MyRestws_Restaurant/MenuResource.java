package com.recourses.MyRestws_Restaurant;

import java.util.List;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.resources.model.Menu;
import com.resources.model.MenuService;

//@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MenuResource {
	private MenuService menuService = new MenuService();
	
	@PermitAll
	@GET
	 public Response getAllMenus(@PathParam("restaurantId") int restaurantId){
		
//		if(menuService.getAllMenus(restaurantId).isEmpty()){
//			return Response.status(Status.NOT_FOUND).build();
//		}
		return Response.status(Status.FOUND)
				.entity(menuService.getAllMenus(restaurantId))
			    .build();
	 }
	

	@RolesAllowed("admin")
	@POST
	public Response addMenu(@PathParam("restaurantId") int restaurantId, Menu menu){
		if(restaurantId<=0){
			return Response.status(Status.NOT_FOUND).build();
		}
		if(menu.getItem().isEmpty() || menu.getPrice()<0){
			return Response.status(Status.BAD_REQUEST).build();
		}
		
		return Response.status(Status.CREATED)
		        .entity(menuService.addMenu(restaurantId, menu))
		        .build();
	}
	
	@RolesAllowed("admin")
	@PUT
	//@Path("/{menuId}")
	@Path("{menuId}")
	public Response updateMenu(@PathParam("restaurantId") int restaurantId, @PathParam("menuId") int id, Menu menu){
		//menu.setId(id);
		return Response.status(Status.OK)
		        .entity(menuService.updateMenu(restaurantId, id,menu))
		        .build();
		
		
	}

	
	
	@RolesAllowed("admin")
	@DELETE
	@Path("{menuId}")
	public Response removeComment(@PathParam("restaurantId") int restaurantId,
			@PathParam("menuId") int Id)
	{

		return Response.status(Status.OK)
				.entity(menuService.removeMenu(restaurantId, Id))
				.build();
	
	}

}
