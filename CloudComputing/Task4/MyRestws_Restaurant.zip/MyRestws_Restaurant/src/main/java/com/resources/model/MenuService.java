package com.resources.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.recourses.Database.DBclass;


public class MenuService {
	
	private HashMap<Integer, Restaurant> restaurants = DBclass.getRestaurants();
	
	
	
	//QueryParam methods:
		public List<Menu> getAllMenusForPrice(double price, int restaurantId ){
			//List<Restaurant> restaurantsForPostalcode = new ArrayList<>();
			List<Menu> menuForPrices = new ArrayList<>();
			Map<Integer, Menu> menus = restaurants.get(restaurantId).getMenus();
			for(Menu menu : menus.values()){
				if(menu.getPrice() == price){
					menuForPrices.add(menu);
				}
			}
			return menuForPrices;
			
		}
	
	//Basic methods:
	public List<Menu> getAllMenus(int restaurantId){
		Map<Integer, Menu> menus = restaurants.get(restaurantId).getMenus();
		return new ArrayList<Menu>(menus.values());
	}
	
	public Menu getMenu(int restaurantId, int menuId){
		Map<Integer, Menu> menus = restaurants.get(restaurantId).getMenus();
		return menus.get(menuId);
	}
	public Menu addMenu(int restaurantId, Menu menu){
		Map<Integer, Menu> menus = restaurants.get(restaurantId).getMenus();
		menu.setId(menus.size() +1);
		menus.put(menu.getId(), menu);
		return menu;
	}
	
	public Menu updateMenu(int restaurantId,int id, Menu menu){
		Map<Integer, Menu> menus = restaurants.get(restaurantId).getMenus();
		if(menu.getId()<=0){
			return null;
		}
		menu.setId(id);
		menus.put(menu.getId(), menu);
		return menu;
		
	}
	
	public Menu removeMenu(int restaurantId, int menuId){
		//restaurant.setId(restaurants.size()-1); --> Something like this to remove from the amount of menus
		Map<Integer, Menu> menus = restaurants.get(restaurantId).getMenus();
		System.out.println(menus);
		System.out.println(menus.get(menuId));
		return menus.remove(menuId);
		
	}
}
