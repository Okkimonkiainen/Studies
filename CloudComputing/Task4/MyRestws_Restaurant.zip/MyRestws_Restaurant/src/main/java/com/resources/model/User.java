package com.resources.model;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

public class User implements Principal {
	private String firstName;
	private String lastName;
	private String login;
	private String password;
	private int id;

	private List<String> role = new ArrayList<String>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public User() {
		
	}
	public User(String firstName, String lastName, String login, String password, int id) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.login = login;
		this.password = password;
		this.id=id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<String> getRole() {
		return role;
	}

	public void setRole(List<String> role) {
		this.role = role;
	}

	public void addRole(String role) {
		this.role.add(role);
		
	}

	@Override
	public String getName() {
		return this.firstName + " " + this.lastName;
		
	}	

}
