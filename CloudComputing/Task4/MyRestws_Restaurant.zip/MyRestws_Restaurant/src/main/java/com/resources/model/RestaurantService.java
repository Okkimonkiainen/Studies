package com.resources.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.recourses.Database.DBclass;



public class RestaurantService {
	private HashMap<Integer, Restaurant> restaurants =DBclass.getRestaurants();	
	
	public RestaurantService(){
		restaurants.put(1, new Restaurant(1, 1,"Torikahvila", "Keskuskatu 7", "2355677", 40100));
		restaurants.put(2, new Restaurant(2,2, "Ruokala", "Yliopistontie 9", "11223213", 40100));
		restaurants.put(3, new Restaurant(3, 3,"Torikahvila", "Torikatu 6", "2354343", 70110 ));
		//menus.put(1L, new Menu(1, "Chicken", "Chicken with whitesauce", 2));
		
	}
	
	
	/*public List<Restaurant> getAllRestaurants(){
		Restaurant r1 = new Restaurant(1, "Torikahvila", "Keskuskatu 7", "2355677");
		Restaurant r2 = new Restaurant(2, "Ruokala", "Yliopistontie 9", "11223213");
		List<Restaurant> list = new ArrayList<>();
		list.add(r1);
		list.add(r2);
		return list;
	}*/
	
	
	//QueryParam methods:
	public List<Restaurant> getAllRestaurantsForPostalcode(int postalcode){
		List<Restaurant> restaurantsForPostalcode = new ArrayList<>();
		for(Restaurant restaurant : restaurants.values()){
			if(restaurant.getPostalcode() == postalcode){
				restaurantsForPostalcode.add(restaurant);
			}
		}
		return restaurantsForPostalcode;
		
	}
	
	public List<Restaurant> getAllRestaurantsPaginated(int start, int size){
		ArrayList<Restaurant> list = new ArrayList<Restaurant>(restaurants.values());
		if(start+size > list.size()) return new ArrayList<Restaurant>();
		return list.subList(start, start+size);
	}
	
	public List<Restaurant> getAllRestaurantsForId(int id){
		List<Restaurant> restaurantsForId = new ArrayList<>();
		for(Restaurant restaurant : restaurants.values()){
			if(restaurant.getId() == id){
				restaurantsForId.add(restaurant);
			}
		}
		return restaurantsForId;
		
	}
	
	
	//Basic methods;
	
	public List<Restaurant> getAllRestaurants(){
	 return new ArrayList<Restaurant>(restaurants.values());
	}
	
	public String getRestaurantsTest(){
		//KOKEILLAAN MUUTTAA HASHMAP STRINGIKSI
		return "Moi";
		
	}
	
	public Restaurant getRestaurant(int id){
		return restaurants.get(id);
	}
	public Restaurant addRestaurant(Restaurant restaurant){
		restaurant.setId(restaurants.size()+1);
		restaurants.put(restaurant.getId(), restaurant);
		return restaurant;
	}
	
	public Restaurant updateRestaurant(Restaurant restaurant){
		if(restaurant.getId()<=0){
			return null;
			
		}
		restaurants.put(restaurant.getId(), restaurant);
		return restaurant;
	}
	
	public Restaurant removeRestaurant(int id){
		//restaurant.setId(restaurants.size()-1); --> Something like this to remove from the amount of restaurants
		restaurants.remove(id);
		return null;
		
		
	}

	@Override
	public String toString() {
		return "RestaurantService [restaurants=" + restaurants + "]";
	}
	
	

}

