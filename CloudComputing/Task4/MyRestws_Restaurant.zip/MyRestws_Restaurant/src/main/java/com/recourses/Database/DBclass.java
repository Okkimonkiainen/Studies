package com.recourses.Database;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.resources.model.Comment;
import com.resources.model.Menu;
import com.resources.model.Owner;
import com.resources.model.Restaurant;
import com.resources.model.User;

public class DBclass {
	private static HashMap<Integer, Restaurant> restaurants = new HashMap<Integer, Restaurant>();
	private static HashMap<String, Menu> menus = new HashMap<String, Menu>();
	private static HashMap<String, Comment> comments = new HashMap<String, Comment>();
	private static HashMap<Integer,User> users = new HashMap<Integer,User>();
	
	private static HashMap<Integer , Owner> owners = new HashMap<Integer , Owner>();


	public static HashMap<Integer, Restaurant> getRestaurants(){
		return restaurants;
	
		
	}
	public static HashMap<Integer , Owner> getOwners()
	{
		return owners;
		
	}
	
	

	public static void setRestaurants(HashMap<Integer, Restaurant> restaurants) {
		DBclass.restaurants = restaurants;
	}

	public static HashMap<String, Menu> getMenus() {
		return menus;
	}

	public static void setMenus(HashMap<String, Menu> menus) {
		DBclass.menus = menus;
	}

	public static HashMap<String, Comment> getComments() {
		return comments;
	}

	public static void setComments(HashMap<String, Comment> comments) {
		DBclass.comments = comments;
	}

	public static HashMap<Integer,User> getUsers() {
		return users;
	}

	public static void setUsers(HashMap<Integer, User> users) {
		DBclass.users = users;
	}

	

	public static void setOwners(HashMap<Integer, Owner> owners) {
		DBclass.owners = owners;
	}
	
}
