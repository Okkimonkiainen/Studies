package com.resources.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.recourses.Database.DBclass;

public class OwnerService 
{
	private HashMap<Integer, Owner> owners =DBclass.getOwners();
	
	public OwnerService()
	{
		/*owners.put(1, new Owner(1,"Mary","0501233535"));
		owners.put(2, new Owner(2,"Nick","05076686565"));
		owners.put(3, new Owner(3,"James","05074754654"));*/
	}
	
	
	public List<Owner> getAllOwners()
	{
	 return new ArrayList<Owner>(owners.values());
	}

	public Owner getOwner(int id)
	{
		return owners.get(id);
	}
	
	
	public Owner addOwner(Owner owner)
	{
		owner.setId(owners.size()+1);
		owners.put(owner.getId(), owner);
		return owner;
	}
	
	public Owner updateOwner(int id,Owner owner)
	{
		if(id < 0)
		{
			return null;
			
		}
		owner.setId(id);
		owners.put(id, owner);
		//return owners.get(ownerId);//owner;
		
		//owners.get(owner.getId()).setName(owner.getName());
		//owners.get(ownerId).setPhoneNumber(owner.getPhoneNumber());
		return owner;
	}
	
	public Owner removeOwner(int id){
		  owners.remove(id);
		  return null;
		
	}


	@Override
	public String toString() {
		return "OwnerService [owners=" + owners + "]";
	}

}
