package com.recourses.MyRestws_Restaurant;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
//import org.glassfish.jersey.internal.util.Base64;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import javax.annotation.Priority;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import org.apache.commons.codec.digest.DigestUtils;

import com.resources.model.User;
import com.resources.model.UserService;
 
/**
 * This filter verify the access permissions for a user
 * based on username and passowrd provided in request
 * */

@Provider
@Priority(Priorities.AUTHENTICATION)
public class SecurityFilter implements ContainerRequestFilter {
	private static final String AUTHORIZATION_PROPERTY = "Authorization";
    private static final String AUTHENTICATION_SCHEME = "Basic ";
    private static final String AUTHORIZATION_HEADER_PREFIX= "Digest ";
    private static final Response ACCESS_DENIED = Response.status(Response.Status.UNAUTHORIZED).build();
    private static final Response ACCESS_FORBIDDEN = Response.status(Response.Status.FORBIDDEN).build();
    private static final Response SERVER_ERROR=Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
   
    private static final String realm = "myrestaurant";

	public String nonce;

    private User user;
    @Context
    private ResourceInfo resourceInfo;
    
    public String calculateNonce() {
        Date d = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy:MM:dd:hh:mm:ss");
        String fmtDate = f.format(d);
        Random rand = new Random(100000);
        Integer randomInt = rand.nextInt();
        return DigestUtils.md5Hex(fmtDate + randomInt.toString());
    }
    

    private String getOpaque(String domain, String nonce) {
        return DigestUtils.md5Hex(domain + nonce);
    }

	
	public void filter(ContainerRequestContext requestContext)
    {
    	UserService userService = UsersResource.getUserService();
		nonce = calculateNonce();
		userService.addNonce(nonce);
        Method method = resourceInfo.getResourceMethod();
		if (method.isAnnotationPresent(PermitAll.class)) {
			return;
		}

		if (method.isAnnotationPresent(DenyAll.class)) {
			abortWithForbidden(requestContext);
			return;
		}
		
		//Get request headers
        //final MultivaluedMap<String, String> headers = requestContext.getHeaders();
          
        //Fetch authorization header
        //final List<String> authorization = headers.get(AUTHORIZATION_PROPERTY);

		List<String> authHeader = requestContext.getHeaders().get(AUTHORIZATION_PROPERTY);
//		System.out.println(authHeader.get(0).startsWith(AUTHENTICATION_SCHEME));
		if (authHeader != null && authHeader.size() > 0) {
			if (authHeader.get(0).startsWith(AUTHENTICATION_SCHEME)) {
				System.out.println(authHeader.get(0).startsWith(AUTHENTICATION_SCHEME));

				user = basic(authHeader, userService, requestContext);

			}
			
			else if (authHeader.get(0).startsWith(AUTHORIZATION_HEADER_PREFIX)) {

				user = digestAuth(authHeader, userService, requestContext);
				if (user == null)
					return;

			}

			if (user == null) {
				abortWithUnauthorized(requestContext);
				return;
			}

			if (method.isAnnotationPresent(RolesAllowed.class)) {
				if (isUserAllowed(user, method.getAnnotation(RolesAllowed.class))) {
					return;
				}
				abortWithForbidden(requestContext);
				return;

			}
		
	abortWithUnauthorized(requestContext);
		return;
		}
	}

	private void abortWithForbidden(ContainerRequestContext requestContext) {
		Response response = Response.status(Response.Status.FORBIDDEN).entity("FORBIDDEN").build();
		requestContext.abortWith(response);
	}

	private boolean isUserAllowed(User user, RolesAllowed annotation) {
		List<String> roles = user.getRole();
		String str = annotation.toString();
		System.out.println(str);
		for (String role : roles) {
			if (str.contains(role)) {
				return true;
			}
		}
		return false;
	}
	

	private User basic(List<String> authorization, UserService userService, ContainerRequestContext requestContext) {
		System.out.println("Tanjim");
		User user = null;
		String auth = authorization.get(0).replaceFirst(AUTHENTICATION_SCHEME, "");
		String usernameAndPassword = new String(Base64.getDecoder().decode(auth.getBytes()));
		System.out.println(usernameAndPassword);
        //Split username and password tokens
        final StringTokenizer tokenizer = new StringTokenizer(usernameAndPassword, ":");
        final String username = tokenizer.nextToken();
        final String password = tokenizer.nextToken();
        System.out.println(userService.checkCredentilas(username, password));
        user = userService.getUser(username);
//		System.out.println(user);
		if (userService.checkCredentilas(username, password)) {
			user = userService.getUser(username);
			System.out.println("Tanjim2");
			String scheme = requestContext.getUriInfo().getRequestUri().getScheme();
			requestContext.setSecurityContext(new MyCustomSecurityContext(user, scheme));
		}
		return user;
		
	}

	private User digestAuth(List<String> authHeader, UserService userService, ContainerRequestContext requestContext) {
		HashMap<String, String> headerValues = parseHeader(authHeader.get(0));

		String userNonce = headerValues.get("nonce");

		if (!userService.getNonces().contains(userNonce)) {
			abortWithUnauthorizedStale(requestContext);
			return null;
		}

		String method = requestContext.getMethod();

		String reqURI = headerValues.get("uri");

		String username = headerValues.get("username");
		User user = userService.getUser(username);
		if (user == null) {
			userService.deleteNonce(userNonce);
			abortWithUnauthorized(requestContext);
			return null;
		}

		String ha1 = DigestUtils.md5Hex(user.getLogin() + ":" + realm + ":" + user.getPassword());
		String ha2 = DigestUtils.md5Hex(method + ":" + reqURI);
		String serverResponse = DigestUtils.md5Hex(ha1 + ":" + userNonce + ":" + ha2);

		String clientResponse = headerValues.get("response");

		if (serverResponse.equals(clientResponse)) {
			String scheme = requestContext.getUriInfo().getRequestUri().getScheme();
			requestContext.setSecurityContext(new MyCustomSecurityContext(user, scheme));
			userService.deleteNonce(userNonce);
			return user;
		}
		abortWithUnauthorized(requestContext);
		return null;
	}

	

	private HashMap<String, String> parseHeader(String header) {
		String headerContent = header.replaceFirst(AUTHORIZATION_HEADER_PREFIX, "");
		HashMap<String, String> headerValues = new HashMap<String, String>();
		String[] valueArray = headerContent.split(",");
		for (String keyVal : valueArray) {
			if (keyVal.contains("=")) {
				String key = keyVal.substring(0, keyVal.indexOf("="));
				String value = keyVal.substring(keyVal.indexOf("=") + 1);
				headerValues.put(key.trim(), value.replaceAll("\"", "").trim());
			}
		}
		return headerValues;
	}



	private String  authHeader() {
		String header = "";

		header += "Digest realm=\"" + realm + "\",";
		header += "nonce=\"" + nonce + "\",";
		header += "opaque=\"" + getOpaque(realm, nonce) + "\"";

		return header;
	}

	
	private void abortWithUnauthorized(ContainerRequestContext requestContext) {

		Response response = Response.status(Response.Status.UNAUTHORIZED).entity("UNAUTHORIZED")
				.header("WWW-Authenticate", authHeader()).build();

		requestContext.abortWith(response);
	}

	private void abortWithUnauthorizedStale(ContainerRequestContext requestContext) {

		Response response = Response.status(Response.Status.UNAUTHORIZED).entity("UNAUTHORIZED-")
				.header("WWW-Authenticate",  authHeader()).header("stale", "true").build();

		requestContext.abortWith(response);
	}
}




