package com.resources.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.recourses.Database.DBclass;

public class CommentService {
	
private HashMap<Integer, Restaurant> restaurants = DBclass.getRestaurants();
	
	
	
	//QueryParam methods:
		public List<Comment> getAllCommentsForId(int id, int restaurantId ){
			//List<Restaurant> restaurantsForPostalcode = new ArrayList<>();
			List<Comment> commentForId = new ArrayList<>();
			Map<Integer, Comment> comments = restaurants.get(restaurantId).getComments();
			for(Comment comment : comments.values()){
				if(comment.getId() == id){
					commentForId.add(comment);
				}
			}
			return commentForId;
			
		}
	
	//Basic methods:
	public List<Comment> getAllComments(int restaurantId){
		Map<Integer, Comment> comments = restaurants.get(restaurantId).getComments();
		return new ArrayList<Comment>(comments.values());
	}
	
	public Comment getComment(int restaurantId, int commentId){
		Map<Integer, Comment> comments = restaurants.get(restaurantId).getComments();
		return comments.get(commentId);
	}
	public Comment addComment(int restaurantId, Comment comment){
		Map<Integer, Comment> comments = restaurants.get(restaurantId).getComments();
		comment.setId(comments.size() +1);
		comments.put(comment.getId(), comment);
		return comment;
	}
	
	public Comment updateComment(int restaurantId, int commentId,Comment comment){
		Map<Integer, Comment> comments = restaurants.get(restaurantId).getComments();
		System.out.println("comment.getId in ypdateComment is "+comment.getId());
		if(comment.getId()<=0){
			return null;
		}
		
		comment.setId(commentId);
		comments.put(comment.getId(), comment);
		return comment;
		
	}
	
	public Comment removeComment(int restaurantId, int commentId){
		//restaurant.setId(restaurants.size()-1); --> Something like this to remove from the amount of menus
		Map<Integer, Comment> comments = restaurants.get(restaurantId).getComments();
		return comments.remove(commentId);
		
	}


}
