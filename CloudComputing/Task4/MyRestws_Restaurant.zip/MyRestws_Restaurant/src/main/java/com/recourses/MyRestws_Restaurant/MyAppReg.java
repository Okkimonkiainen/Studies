package com.recourses.MyRestws_Restaurant;
import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.glassfish.jersey.server.ResourceConfig;

public class MyAppReg extends ResourceConfig{
	public MyAppReg(){
		
		
		register(SecurityFilter.class);
		//register(RestaurantResource.class); //maybe needed?
		//register(RolesAllowedDynamicFeature.class); //We might not need this?
		//register(RolesAllowedDynamicFeature.class);
		}
}
