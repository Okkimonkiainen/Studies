import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('TIES4560_MEDICINES')

def lambda_handler(event, context):
    try:
        table.put_item(Item = event)
        message = 'Medicine Added Successfully!'
        return {
        "statusCode": 201,
        "message": message
        }
    except:
        message = 'Could Not Add Medicine!'
        return {
            "statusCode": 400,
            "message": message
        }
        