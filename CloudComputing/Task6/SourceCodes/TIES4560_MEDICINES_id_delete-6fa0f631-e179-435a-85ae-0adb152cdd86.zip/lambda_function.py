import json
import boto3
from pprint import pprint
from boto3.dynamodb.conditions import Key
from boto3.dynamodb.conditions import Key, Attr

dynamodb= boto3.resource('dynamodb')
table=dynamodb.Table('TIES4560_MEDICINES')

def lambda_handler(event, context):
     try:
        value = event['id'] #now we get the correct value!
        response = table.get_item(Key={'MEDICINE_ID': value})
        print(response['Item'])
        table.delete_item(Key={'MEDICINE_ID': value})
        message='Medicine Deleted Successfully!'
        #print(table.get_item(Key={'MEDICINE_ID': value}))
        
        return {
                   "statusCode":200,
                   "message": message
                
                 }
     except:
         message='Id does not exist'
         return {
                     "statusCode":404,
                     "message": message
                 }
