import json
import boto3
from pprint import pprint
from boto3.dynamodb.conditions import Key
from boto3.dynamodb.conditions import Key, Attr

dynamodb= boto3.resource('dynamodb')
table=dynamodb.Table('TIES4560_MEDICINES')

def lambda_handler(event, context):
     
     try:
                value = event['id'] #now we get the correct value!
                response = table.get_item(Key={'MEDICINE_ID': value})
                return response['Item']
     except:
             message='Id does not exist'
             return {
                     "statusCode":404,
                     "message": message
                 }
        