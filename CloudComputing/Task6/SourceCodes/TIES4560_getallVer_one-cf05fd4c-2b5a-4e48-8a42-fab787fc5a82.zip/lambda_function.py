import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb= boto3.resource('dynamodb')
table=dynamodb.Table('TIES4560_MEDICINES')


def lambda_handler(event, context):
    #logger.info('got event{}'.format(event))
    queryRes = table.scan()
    print(queryRes)
    return