import json
import boto3
from pprint import pprint
from boto3.dynamodb.conditions import Key
from boto3.dynamodb.conditions import Key, Attr

dynamodb= boto3.resource('dynamodb')
table=dynamodb.Table('TIES4560_MEDICINES')

def lambda_handler(event, context):
       try:
        data = event['body']
        table.put_item(Item=data)
        
        message = 'Medicine Updated Successfully!'
        return {
            "statusCode": 200,
            "message": message
        }
       except:
        message = 'Could Not Update Medicine!'
        return {
            "statusCode": 400,
            "message": message
        }

        
