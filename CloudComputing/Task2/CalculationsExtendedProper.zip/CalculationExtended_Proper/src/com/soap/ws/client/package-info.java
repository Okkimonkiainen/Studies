@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.soap.ws.client;
