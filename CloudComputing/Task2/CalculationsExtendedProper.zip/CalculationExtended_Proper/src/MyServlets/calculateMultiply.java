package MyServlets;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.google.gson.Gson;

import ws.client.Calculator;
import ws.client.CalculatorSoap;



/**
 * Servlet implementation class calculateMultiply
 */
@WebServlet("/calculateMultiply")
public class calculateMultiply extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public calculateMultiply() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String valueString = request.getParameter("valueString").toString();
		String valueStringTwo = request.getParameter("valueStringTwo").toString();
		System.out.println("valueString= "+valueString);
		System.out.println("valueStringTwo= "+valueStringTwo);
		
		//Changed the the string value to number for calculations:
		int value1 = Integer.parseInt(valueString);
		int value2 = Integer.parseInt(valueStringTwo);
		
		Calculator obj1 = new Calculator();
		CalculatorSoap serv = obj1.getCalculatorSoap();
		
		//Multiplying the two values: 
		int result_multiply = serv.multiply(value1, value2);
	   System.out.println("result_multiply= "+result_multiply);
	   
	   //For clarity changed back to string just in case:
	   String result_multi = Integer.toString(result_multiply);
	   System.out.println("result_multi= "+result_multi);
	   
	   
	   String st = "<value>"+result_multi+"</value>";
	   
	   
	   
	   if(!result_multi.equals("null")){
		   org.json.JSONObject json = new org.json.JSONObject();
		   
		   System.out.println("Hello, the result doesn't equal 'null'! :)");
		   try{
			   
			   json = XML.toJSONObject(st); 
			   
			   
		   }catch(JSONException e){
			   e.printStackTrace();
			   System.out.println("Hello, we got an exception here! :D");
			   
		   }
		   response.setContentType("application/json");
		    response.setCharacterEncoding("UTF-8");
		    response.getWriter().write(json.toString());
		   
	   }else{
		   Map<String, String> options = new LinkedHashMap<>();
		   options.put("message", "Is not found");
		   String json = new Gson().toJson(options);
		   
		   response.setContentType("application/json");
		   response.setCharacterEncoding("UTF-8");
		   response.setStatus(404);
		   response.getWriter().write(json.toString());
		   System.out.println("Hello, we came here! Errortime 404 :)!");
		   
	   }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
