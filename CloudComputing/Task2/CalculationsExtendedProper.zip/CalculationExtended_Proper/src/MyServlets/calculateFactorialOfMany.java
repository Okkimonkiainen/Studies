package MyServlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.google.gson.Gson;
import com.soap.ws.client.CalculationService;
import com.soap.ws.client.CalculationServiceService;


/**
 * Servlet implementation class calculateFactorialOfMany
 */
@WebServlet("/calculateFactorialOfMany")
public class calculateFactorialOfMany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public calculateFactorialOfMany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		StringBuffer request_body = new StringBuffer();
		String line =null;
		try{
			BufferedReader reader = request.getReader();
			while((line= reader.readLine()) !=null)
				 request_body.append(line);
				
		}catch(Exception e){}
		
		if(!request_body.toString().equals("")){ //if request is empty
			response.setStatus(302);
			
			if(request_body.toString().matches(".*\\d.*")){
				response.sendRedirect("/calculateFactorial?valueString="+request_body.toString());	
			}
			else{
				Map<String, String> options = new LinkedHashMap<>();
				options.put("message", "Bad Request: body of the request message is empty or incomplete");
				String json = new Gson().toJson(options);
				
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");
				response.setStatus(400);
				response.getWriter().write(json.toString());	
				
			}
		}else{
			Map<String, String> options = new LinkedHashMap<>();
			options.put("message", "Bad Request: body of the request message is empty or incomplete");
			String json = new Gson().toJson(options);
			
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.setStatus(400);
			response.getWriter().write(json.toString());
			
		}
	}

}


