package MyServlets;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.google.gson.Gson;
import com.soap.ws.client.CalculationService;
import com.soap.ws.client.CalculationServiceService;

//T�H�N MAHDOLLISESTI MY�S IMPORTATAAN KANSIOSTA WS.CLIENT TIEDOSTOJA CALCULATOR JA CALCULATORSOAP

/**
 * Servlet implementation class calculateFactorial
 */
@WebServlet("/calculateFactorial")
public class calculateFactorial extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public calculateFactorial() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String valueString = request.getParameter("valueString").toString();
		System.out.println("valueString= "+valueString);
		
		CalculationServiceService service = new CalculationServiceService();
		CalculationService obj = service.getCalculationService();
		
//Changed the the string value to number for calculations:
	   int factorial= Integer.parseInt(valueString);
	   System.out.println("factorial= "+factorial);
	   
	   int result_factorial=obj.factorial(factorial);
	   System.out.println("result_factor= "+result_factorial);
	   
	   //For clarity changed back to string just in case:
	   String result_fact = Integer.toString(result_factorial);
	   System.out.println("result_fact= "+result_fact);
	   
	   
	   String st = "<value>"+result_fact+"</value>";
	   
	   
	   
	   if(!result_fact.equals("null")){
		   org.json.JSONObject json = new org.json.JSONObject();
		   
		   System.out.println("Hello, the result doesn't equal 'null'! :)");
		   try{
			   
			   json = XML.toJSONObject(st); 
			   
			   
		   }catch(JSONException e){
			   e.printStackTrace();
			   System.out.println("Hello, we got an exception here! :D");
			   
		   }
		   response.setContentType("application/json");
		    response.setCharacterEncoding("UTF-8");
		    response.getWriter().write(json.toString());
		   
	   }else{
		   Map<String, String> options = new LinkedHashMap<>();
		   options.put("message", "Is not found");
		   String json = new Gson().toJson(options);
		   
		   response.setContentType("application/json");
		   response.setCharacterEncoding("UTF-8");
		   response.setStatus(404);
		   response.getWriter().write(json.toString());
		   System.out.println("Hello, we came here! Errortime 404 :)!");
		   
	   }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
