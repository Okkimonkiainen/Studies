package MyServlets;

import java.io.IOException;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.google.gson.Gson;
import com.soap.ws.client.CalculationService;
import com.soap.ws.client.CalculationServiceService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class calculateModulo
 */
@WebServlet("/calculateModulo")
public class calculateModulo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public calculateModulo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String valueString = request.getParameter("valueString").toString();
		String valueStringTwo = request.getParameter("valueStringTwo").toString();
		System.out.println("valueString= "+valueString);
		System.out.println("valueStringTwo= "+valueStringTwo);
		
		CalculationServiceService service = new CalculationServiceService();
		CalculationService obj = service.getCalculationService();
		
//Changed the the string value to number for calculations:
	   int valueOne= Integer.parseInt(valueString);
	   int valueTwo= Integer.parseInt(valueStringTwo);
	   System.out.println("valueOne= "+valueOne);
	   System.out.println("valueTwo= "+valueTwo);
	   
	   int result_modulo=obj.modulo(valueOne, valueTwo);
	   System.out.println("result_modulo= "+result_modulo);
	   
	   //For clarity changed back to string just in case:
	   String result_mod = Integer.toString(result_modulo);
	   System.out.println("result_mod= "+result_mod);
	   
	   //to xml-style:
	   String st = "<value>"+result_mod+"</value>";
	   
	   
	   
	   if(!result_mod.equals("null")){
		   org.json.JSONObject json = new org.json.JSONObject();
		   
		   System.out.println("Hello, the result doesn't equal 'null'! :)");
		   try{
			   
			   json = XML.toJSONObject(st); 
			   
			   
		   }catch(JSONException e){
			   e.printStackTrace();
			   System.out.println("Hello, we got an exception here! :D");
			   
		   }
		   response.setContentType("application/json");
		    response.setCharacterEncoding("UTF-8");
		    response.getWriter().write(json.toString());
		   
	   }else{
		   Map<String, String> options = new LinkedHashMap<>();
		   options.put("message", "Is not found");
		   String json = new Gson().toJson(options);
		   
		   response.setContentType("application/json");
		   response.setCharacterEncoding("UTF-8");
		   response.setStatus(404);
		   response.getWriter().write(json.toString());
		   System.out.println("Hello, we came here! Errortime 404 :)!");
		   
	   }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
