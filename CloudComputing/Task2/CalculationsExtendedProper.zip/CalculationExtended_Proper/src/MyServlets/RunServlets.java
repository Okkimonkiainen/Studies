package MyServlets;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletHandler;

public class RunServlets {

	public static void main(String[] args) {
		ServletHandler handler = new ServletHandler();
		handler.addServletWithMapping(calculateFactorial.class, "/calculateFactorial");
		handler.addServletWithMapping(calculateMultiply.class, "/calculateMultiply");
		handler.addServletWithMapping(calculateAverage.class, "/calculateAverage");
		handler.addServletWithMapping(calculateModulo.class, "/calculateModulo");
		handler.addServletWithMapping(calculateFactorialOfMany.class, "/calculateFactorialOfMany");
		handler.addServletWithMapping(calculateAverageOfMany.class, "/calculateAverageOfMany");
		//handler.addServletWithMapping(calculateAverageOfMany.class, "/calculateAverageOfMany");
		
		
		//Creating a new server:
		Server server = new Server(1240);
		server.setHandler(handler);
		try{
			server.start();
			
			
			
		}catch(Exception e){
			
			e.printStackTrace();
			System.out.println("We can't start the server! :("); 
		}
		//a lot of debug output to the console:
		server.dumpStdErr();
		
		try{
			server.join();
		}catch(Exception e){
			
			e.printStackTrace();
			System.out.println("We can't join the server! :(");
		}

	}

}
