"use strict";
// seuraavat estävät jshintin narinat leafletin objekteista
/*globals L*/

// Alustetaan data, joka on jokaisella sivun latauskerralla erilainen.
window.addEventListener("load", function(e) {
	fetch('https://appro.mit.jyu.fi/cgi-bin/tiea2120/randomize_json.cgi')
	    .then(response => response.json())
	    .then(function(data) {
            console.log(data);
            // tänne oma koodi
			let kaikkiData=data;
			//Luodaan kartta
			let mapDiv=document.getElementById('map');
			let map = new L.map('map', {
				crs:L.TileLayer.MML.get3067Proj()
			}).setView([62.2333, 25.7333], 11);
			L.tileLayer.mml_wmts({layer: "maastokartta", key:"cdfef63c-5fb7-4d0d-a008-7d72c2f611bd"}).addTo(map);
			//Luodaan punaiset ympyrät kartalle:
			let polylineArr=[];
			luodaanYmpyrat(data.rastit, map, kaikkiData, polylineArr);
			
			
			//Luodaan joukkueet-osio
			luodaanJoukkueet(data.joukkueet, data.rastit);
			//Luodaanrastit-osio
			luodaanRastit(data.rastit);
			//Luodaan tyhjä Kartalla lista-osio:
			let div=document.getElementById('kartalla');
			let ul=document.createElement('ul');
			ul.setAttribute("id","kartallaLista");
			div.appendChild(ul);

			//Kaikki raahattavat elementit voidaan siirtää wordpadiin:
			let body=document.querySelector('body');
			body.addEventListener("dragover",function(e){
				e.preventDefault();
		
			});
				body.addEventListener("drop",function(e){
					e.preventDefault();
			
			});
			//Muutetaan joukkuelista raahattavaksi:
			let listaJoukkue=document.getElementById('joukkuelista').children;
			for(let joukkue of listaJoukkue){
				joukkue.addEventListener("dragstart",function(e){
					e.dataTransfer.setData("joukkue",e.target.id);
					e.dataTransfer.effectAllowed="move";
					//Wordpadille siirtoa varten:
					let nimi=e.target.textContent.substring(0, e.target.textContent.indexOf('(')).trim();
					e.dataTransfer.setData("text/plain",nimi);
				});
			}
			//Muutetaan rastilista raahattavaksi:
			let rastiLista=document.getElementById('rastilista').children;
			for(let rasti of rastiLista){
				rasti.addEventListener("dragstart",function(e){
					
					e.dataTransfer.setData("rasti",e.target.id);
					e.dataTransfer.effectAllowed="move";
					//Wordpadille siirtoa varten:
					e.dataTransfer.setData("text/plain",e.target.rasti.koodi);
				});
			}
			let pudotusalue=document.getElementById('kartallaLista');
			
			
			pudotusalue.addEventListener("dragover",function(e){
				e.preventDefault();
				if(e.dataTransfer.types.includes("joukkue")||e.dataTransfer.types.includes("rasti")){
					e.dataTransfer.dropEffect="move";
				}
			});
			//Pudotetaan kartalla-alueelle:
			pudotusalue.addEventListener("drop",function(e){
				
				let data;
				let x= e.offsetX;
				let y= e.offsetY;
				
				if(e.dataTransfer.types.includes("joukkue")){
					data=e.dataTransfer.getData("joukkue");
				}else if(e.dataTransfer.types.includes("rasti")){
					data=e.dataTransfer.getData("rasti");
				}
				
				let li=document.getElementById(data);
				let kartallaLi=document.getElementById('kartallaLista').children;
				let olemassa=false;
				for(let likartta of kartallaLi){
					if(li==likartta){
						olemassa=true;
					}
				}
				if(e.target.tagName.trim().toLowerCase()=="li"){
					let ul=e.target.parentNode;
					ul.insertBefore(document.getElementById(data),e.target);
					
				}
				else{ 
					e.target.appendChild(document.getElementById(data));
				}
				
				
				//console.log("UL KORKEUS ja LEVEYS");
				//console.log(ul.clientHeight);
				//console.log(ul.clientWidth);
				//console.log("LI KORKEUS ja LEVEYS");
				//console.log(y);
				//console.log(x);
				
				//Asetetaan joukkue hiiren osoittamaan kohtaan, kunhan joukkue ei asetu liian lähelle reunoja
				if(e.dataTransfer.types.includes("joukkue")){
				if(x<236){ //236
				li.style.top=y+"px";
				li.style.left=x+"px";
				li.style.width="fit-content";
				li.style.position= "absolute";
				}else{
					x= x-100;
					li.style.top=y+"px";
					li.style.left=x+"px";
					li.style.width="fit-content";
					li.style.position= "absolute";
				}
				if(ul.clientHeight-y<20){
					y=y-20;
					li.style.top=y+"px";
					li.style.left=x+"px";
					li.style.width="fit-content";
					li.style.position= "absolute";
				}
			//Asetetaan rasti hiiren osoittamaan kohtaan, kunhan rasti ei asetu liian lähelle reunoja
			}else if(e.dataTransfer.types.includes("rasti")){
					if(x<236){ //236
					li.style.top=y+"px";
					li.style.left=x+"px";
					li.style.width="fit-content";
					li.style.position= "absolute";
					}else{
						x= x-60;
						li.style.top=y+"px";
						li.style.left=x+"px";
						li.style.width="fit-content";
						li.style.position= "absolute";
					}
					if(ul.clientHeight-y<20){
						y=y-20;
						li.style.top=y+"px";
						li.style.left=x+"px";
						li.style.width="fit-content";
						li.style.position= "absolute";
					}
			}

				//Piirretään reitti:
				let tiputettu=document.getElementById(data);
				if(e.dataTransfer.types.includes("joukkue")){
					if(olemassa==false){
					let kaikkiRastit=[];//sisältää kaikki rastit lahto ja maali väliltä
					let valitutAjat=[]; //sisältää lahto ja maali-rastin
					valitutAjat=kaikkiAjat(tiputettu.joukkue, kaikkiData.rastit);
					kaikkiRastit=haetutRastit(valitutAjat, tiputettu.joukkue);
					if(kaikkiRastit.length>0){
					polylineArr.push(piirretaanPolyline(kaikkiRastit,kaikkiData.rastit, tiputettu, map));
					}
					}
				}
				
			});


			//Raahaus takaisin joukkue-listaan:
			let joukkueLista=document.getElementById('joukkuelista');
			let pudotusDiv=document.getElementById('joukkuelista');
			let kartalla=document.getElementById('kartallaLista').children;
			for(let elementti of kartalla){
				elementti.addEventListener("dragstart",function(e){
					if(e.dataTransfer.types.includes("joukkue")){
						e.dataTransfer.dropEffect="move";
					}
					
				});
			}
			pudotusDiv.addEventListener("dragover",function(e){
				e.preventDefault();
				if(e.dataTransfer.types.includes("joukkue")){
					e.dataTransfer.dropEffect="move";
				}
			});
			pudotusDiv.addEventListener("drop",function(e){
				let data;
				if(e.dataTransfer.types.includes("joukkue")){
					data=e.dataTransfer.getData("joukkue");
				}
				let li=document.getElementById(data);
				if(e.dataTransfer.types.includes("joukkue")){
					
					li.style.top="";
					li.style.left="";
					li.style.width="";
					li.style.position="";
					//Asetetaan valittu joukkue ennen li-kohde-elementtiä
					if(e.target.tagName.trim().toLowerCase()=="li"){
						let ul=e.target.parentNode;
						ul.insertBefore(document.getElementById(data),e.target);
					}else{ 
						e.target.appendChild(document.getElementById(data));
					}
					//Poistetaan joukkueen reitti kartalta:
					let valittuJoukkue=document.getElementById(data);
					for(let polyline of polylineArr){
						
						if(polyline.options.id==valittuJoukkue.id){
							polyline.remove(map);
						}
					}
			  }
				
			});
			//Raahaus takaisin rasti-listaan:
			let rastiPudotus=document.getElementById('rastilista');
			rastiPudotus.addEventListener("dragover",function(e){
				e.preventDefault();
				if(e.dataTransfer.types.includes("rasti")){
					e.dataTransfer.dropEffect="move";
				}
			});
			rastiPudotus.addEventListener("drop",function(e){
				let data;
				if(e.dataTransfer.types.includes("rasti")){
					data=e.dataTransfer.getData("rasti");
				}
				let li=document.getElementById(data);
				if(e.dataTransfer.types.includes("rasti")){
					li.style.top="";
					li.style.left="";
					li.style.width="";
					li.style.position="";
					//Asetetaan tarvittaessa rasti ennen li-kohde-elementtiä
					if(e.target.tagName.trim().toLowerCase()=="li"){
						let ul=e.target.parentNode;
						ul.insertBefore(document.getElementById(data),e.target);
					}else{ 
						e.target.appendChild(document.getElementById(data));
					}
			  }
				
			});




	    });


});

//Joukkueen reitti piirretään ja tuodaan kartalle päälimmäiseksi:
function piirretaanPolyline(joukkueRastit, rastit, joukkuedata, map){
	let Koordinaatit=[];
	let varit=[];
	for(let rasti of joukkueRastit){
		let latlngs=[];
		for(let rastiData of rastit){
			if(rasti.rasti==rastiData.id){
				latlngs.push(rastiData.lat, rastiData.lon);
				varit.push();
			}
		}
		Koordinaatit.push(latlngs);
	}
	let polyline=L.polyline(Koordinaatit, {color:joukkuedata.style.backgroundColor, id: joukkuedata.id}).addTo(map);
	
	polyline.bringToFront();
	return polyline;
}

//Joukkueen kulkeman matkan laskeminen:
function laskettuMatka(joukkue, rastit){
	let valitutAjat=[];
	let valitutRastit=[];
	valitutAjat=kaikkiAjat(joukkue,rastit);
	valitutRastit=haetutRastit(valitutAjat,joukkue);
	let matka=0.0;
	let edellinenRasti;
	let rastiTiedot=[];
	for(let rasti of valitutRastit){
		for(let loydetty of rastit){
			if(rasti.rasti==loydetty.id){
				rastiTiedot.push(loydetty);
			}
		}
	}

	
	for(let i=0; i<rastiTiedot.length;i++){
		if(i==0){

			edellinenRasti=rastiTiedot[i];
		}else{
			matka+=getDistanceFromLatLonInKm(rastiTiedot[i].lat,rastiTiedot[i].lon,
				edellinenRasti.lat, edellinenRasti.lon);
				edellinenRasti=rastiTiedot[i];
		}
	}
	joukkue.matka=matka;
	return joukkue;
	//return matka;//Math.round(matka);

}

//Kaikkien rastien hakeminen aikaisemmin haettujen lahto- ja maali-rastien avulla
function haetutRastit(valitutAjat,joukkue){ //valitutAjat sisältää lahto- ja maali-rastin
	let joukkueRastiArr=Array.from(joukkue.rastileimaukset);
		joukkueRastiArr.sort(function aikaVertailu(a,b){
			return new Date(a.aika)- new Date(b.aika);
		});

		//Vähän hassu ratkasu(korjataan monikäyttöiseksi jos ehditään):
		if(valitutAjat.length>2){
			let j=0;
			for(let i=0; i<valitutAjat.length;i++){
				if(valitutAjat[i].rasti==valitutAjat[1].rasti){
					valitutAjat[i]=valitutAjat[1];
					valitutAjat[i+1]=valitutAjat[2];
					j+=1;
					valitutAjat.pop();
				}
			}
		}
		
		let lahtoindeksi=joukkueRastiArr.indexOf(valitutAjat[0]);
		let maaliindeksi=joukkueRastiArr.indexOf(valitutAjat[1]);
		let kaikkiRastit=[];
		//Tallennetaan rastit, jotka sijoittuvat lahto- ja maali-rastin väliin
		for(let rasti of joukkueRastiArr){
			let indeksi=joukkueRastiArr.indexOf(rasti);
			for(let valitturasti of valitutAjat){
				if(!rasti.hasOwnProperty('rsti')){
				if(rasti==valitturasti){
					kaikkiRastit.push(rasti);
				}else if(indeksi>lahtoindeksi&&indeksi<maaliindeksi&&rasti.rasti!=valitutAjat[0].rasti&&rasti.rasti!=valitutAjat[1].rasti){ 
						
					
					if(!kaikkiRastit.includes(rasti)){
						kaikkiRastit.push(rasti);
					}
				}
			}

			}
		}
		return kaikkiRastit;
}

//Haetaan joukkueen lahto- ja maali-rasti
function kaikkiAjat(joukkue, rastit){
	let kaikkiRastit=[];
	let valitutAjat=[];
	let lahtoAika=[];
	let maaliAika=[];
	if(joukkue.rastileimaukset.length!=0){
		for(let rasti of joukkue.rastileimaukset){
			for(let dataRasti of rastit){
				if(dataRasti.id==rasti.rasti){
					if(dataRasti.koodi=="LAHTO"){
						lahtoAika.push(rasti);
					}else if(dataRasti.koodi=="MAALI"){
						maaliAika.push(rasti);
					}
				}
			}
		}
		//console.log("Ajat");
		//console.log(lahtoAika);
		//console.log(maaliAika);
		let ajatLM=lahtoAika.concat(maaliAika);
		ajatLM.sort(function aikaVertailu(a,b){
			return new Date(a.aika)- new Date(b.aika);
		});
		//console.log("Ajat lm");
		//console.log(ajatLM);
		
		
		let indexStart=0; //LAHTO-rastin indeksi
		let indexEnd=0; //MAALI-rastin indeksi
		let lahtoaikaStr="";//Aikaan liittyvät asiat säilytetty testausta varten 
		let loppuaikaStr="";
		for(let value of ajatLM){
			for(let valueTwo in value){
				for(let rasti of rastit){
			  if(value[valueTwo]===rasti.id&&rasti.koodi=="LAHTO"){
				lahtoaikaStr=value.aika; 
				if(valitutAjat.includes(value)){
					let paikka=valitutAjat.indexOf(value);
					valitutAjat[paikka]=value;
					indexStart=ajatLM.indexOf(value);
				}else{
					valitutAjat.push(value);
					indexStart=ajatLM.indexOf(value);
				}
			  }
			  if(value[valueTwo]===rasti.id&&rasti.koodi=="MAALI"){
				indexEnd=ajatLM.indexOf(value); //maali indeksi
				  if(indexStart+1===indexEnd){ //jos maali indeksi lahtoindeksin jälkeen, otetaan maali talteen
					loppuaikaStr=value.aika;
					valitutAjat.push(value);
				  } 
			  }
			}  
			}
		  }
		  

		
		
		
		//Lahto ja maaliaikojen testaus, jotta valitaan varmasti oikea maali ja lahto-aika
		//Jätetty vain testauksen takia:
		let lahto=new Date(lahtoaikaStr); 
			let maali=new Date(loppuaikaStr); 
			let interval= new Date(maali.getTime()-(lahto.getTime()+2*60*60*1000));
			let intervalStr=""; 
		  
			intervalStr=interval.toString(); 
			intervalStr=intervalStr.substring(16, 16+8);
		  	//console.log("JOUKKUEEN AIKA");
			//console.log(joukkue);
			//console.log(intervalStr);

	}
	return valitutAjat;//joukkueen maali- ja lahto-aika
}




//Muodostaa kartalle ympyrät rasteista sekä käsittelee ympyröiden siirtämisen:
function luodaanYmpyrat(rastit, map, kaikkiData, polylineArr){
	let rajat=L.latLngBounds();
	let klikattuYmpyra=[];
	let klikattuMarker=[];
	for(let rasti of rastit){
		let rastiPaikka=[rasti.lat, rasti.lon];
		rajat.extend(rastiPaikka);
		let ympyra=L.circle(
			[rasti.lat, rasti.lon],{
				color:'red',
				radius:150,
				fillColor: '',
				fillOpacity:0
			}
			).addTo(map);
			//rastin koodin asettaminen ympyrän keskelle
			ympyra.bindTooltip(rasti.koodi,{permanent:true, direction:"center", opacity:0.5});

			//Jos ympyrään klikataan, muodostetaan markkeri ja sen avulla siirretään ympyrää:
			ympyra.addEventListener("click",function(e){
				
				let marker;
				//Markkeri muodostuu sen ympyrän päälle jota klikataan:
				if(klikattuMarker.length==0){
					
					marker = L.marker(rastiPaikka).addTo(map);
					klikattuMarker.push(marker);
					klikattuYmpyra.push(ympyra);
					ympyra.setStyle({fillColor: 'red',fillOpacity:100}); 
				}else{//Jos edellistä klikattua ympyrää ei siirretä ja klikataankin toista ympyrää:
					let edellinenMarker=klikattuMarker.pop();
					let edellinenYmpyra=klikattuYmpyra.pop();
					edellinenYmpyra.setStyle({fillColor: '',fillOpacity:0});
					edellinenMarker.remove(map);
					marker = L.marker(rastiPaikka).addTo(map);
					klikattuMarker.push(marker);
					klikattuYmpyra.push(ympyra);
					ympyra.setStyle({fillColor: 'red',fillOpacity:100});

				}//Ympyrä vaihtaa paikkaa markerin osoittamaan kohtaan:
				marker.dragging.enable();
				marker.addEventListener("dragend",function(e){
					let paikka=marker.getLatLng();
					
					rastiPaikka=paikka;
					ympyra.setLatLng(rastiPaikka);
					//rajat.extend(rastiPaikka); jos haluaa huomioida kartan keskittämisessä myös uudet rastit
						
											
					let rastiData=Array.from(rastit);
					let edellinenLat=rasti.lat;
					let edellinenLon=rasti.lon;
					rasti.lat=paikka.lat;
					rasti.lon=paikka.lng;
					//Haetaan kartalla-listassa olevat joukkue li-elementit
					let kartalla=document.getElementById("kartallaLista").children;
					let liElementit=[];
					for(let elementti of kartalla){
						if(elementti.tagName.trim().toLowerCase()=="li"){
							let joukkueLi=elementti;
							if(elementti.id.includes('joukkue')){
								liElementit.push(elementti);
							}
							
						}
					}
					if(liElementit.length>0){
						//Jos kartalla oleva joukkue käyttää paikkaavaihtantta rastia, päivitetään sen tiedot:
						for(let li of liElementit){
							let rastiOlemassa=false;
							console.log(li);
							let rastileiArr=li.joukkue.rastileimaukset;
							
							for(let rastilei of rastileiArr){
								if(rastilei.rasti==rasti.id){
									rastiOlemassa=true;
								}
							}
							
							//Päivitetään joukkueen tietoja:reitinpiirtäminen ja matkan laskeminen uudestaan:
							if(rastiOlemassa==true){
								let kaikkiRastit=[];
								let valitutAjat=[];
								valitutAjat=kaikkiAjat(li.joukkue, kaikkiData.rastit);
								kaikkiRastit=haetutRastit(valitutAjat, li.joukkue);
								if(kaikkiRastit.length>0){
									let vanhaPolyline;
									for(let polyline of polylineArr){
										let objekti=(polyline.getLatLngs());
										for(let obj in objekti){
											if(objekti[obj].lat==edellinenLat&&objekti[obj].lng==edellinenLon){
												
												vanhaPolyline=polyline;
											}
										}
										
									}
									let indeksiVanha=polylineArr.indexOf(vanhaPolyline);
									console.log("vanha");
									console.log(vanhaPolyline);
									vanhaPolyline.remove(map);
									let polylineUusi=piirretaanPolyline(kaikkiRastit,kaikkiData.rastit, li, map);
									
									polylineArr[indeksiVanha]=polylineUusi;
									
									
									let joukkueMuok=laskettuMatka(li.joukkue, kaikkiData.rastit);
									let matka=joukkueMuok.matka.toFixed(1);
									if(matka.toString().includes('.')){
										matka=matka.toString().split('.')[1];
										
										//kartalla-listauksessa olevien joukkueiden matkojen päivitys:
										if(matka[0]=="0"){
											li.textContent=li.joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(0)+" km)";
										}else{
											li.textContent=li.joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(1)+" km)";
										}
									}else{
										li.textContent=li.joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(0)+" km)";
									}
									
										
								}
							}
						}
					}
					//Matkan päivitys vielä erikseen joukkueListaan:
					let joukkueetLi=document.getElementById('joukkuelista').children;
					
					for(let li of joukkueetLi){
						for(let rastileimaus of li.joukkue.rastileimaukset){
							if(rastileimaus.rasti==rasti.id){
								
									let joukkueMuok=laskettuMatka(li.joukkue, kaikkiData.rastit);
									let matka=joukkueMuok.matka.toFixed(1); //split('.');
									if(matka.toString().includes('.')){
										matka=matka.toString().split('.')[1];
										
										
										if(matka[0]=="0"){
											li.textContent=li.joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(0)+" km)";
										}else{
											li.textContent=li.joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(1)+" km)";
										}
									}else{
										li.textContent=li.joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(0)+" km)";
									}
									
								}
					}
				}
					
					
					
					
					//Poista marker ja ympyrän väri takaisin normaaliksi, kun siirto tapahtunut:
					marker.remove(map);
					ympyra.setStyle({fillColor: '',fillOpacity:0});
					
					
				});
				
			});

			
	}
	map.fitBounds(rajat); //kartta keskittynyt ympyröiden mukaisesti

}

//Datan rastien luonti listaan:
function luodaanRastit(rastitArr){
	let rastit=Array.from(rastitArr);
	rastit.sort(function(a,b){
		let koodiA=a.koodi.trim().toLowerCase();
		let koodiB=b.koodi.trim().toLowerCase();
		if(koodiA<koodiB){
			return 1;
		}else if(koodiA>koodiB){
			return -1;
		}
		return 0;
	});
	//Tehdään listat:
	luodaanListaRastit(rastit);
}
function luodaanListaRastit(rastit){
	let div=document.getElementById('rastit');
	let ul=document.createElement('ul');
	ul.setAttribute("id","rastilista");
	let i=0;
	for(let rasti of rastit){
		let li=document.createElement('li');
		li.setAttribute("id","rasti"+i);
		li.textContent=rasti.koodi.trim();
		let vari=rainbow(rastit.length, i);
		li.style.backgroundColor=vari;
		li.setAttribute("draggable","true");
		li.rasti=rasti;
		ul.appendChild(li);
		i++;
	}
	div.appendChild(ul);
}

//Datan joukkueiden luonti listaan:
function luodaanJoukkueet(joukkueArr, rastit){
	let joukkueet=Array.from(joukkueArr);
	//Aakkosjärjestykseen:
	joukkueet.sort(function(a, b){
		let nimiA=a.nimi.trim().toLowerCase();
		let nimiB=b.nimi.trim().toLowerCase();
		if(nimiA<nimiB){
			return -1;
		}else if(nimiA>nimiB){
			return 1;
		}
		return 0;
	});
	//Tehdään lista:
	luodaanListaJoukkueet(joukkueet, rastit);
}
function luodaanListaJoukkueet(joukkueet, rastit){
	let joukkueMuok;
	let div=document.getElementById('joukkueet');
	let ul=document.createElement('ul');
	ul.setAttribute("id","joukkuelista");
	let i=0;
	for(let joukkue of joukkueet){
		joukkueMuok=laskettuMatka(joukkue, rastit);
		let li=document.createElement('li');
		li.setAttribute("id","joukkue"+i);
		let matka=joukkueMuok.matka.toFixed(1);
		if(matka.toString().includes('.')){
			matka=matka.toString().split('.')[1];
			if(matka[0]=="0"){
				li.textContent=joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(0)+" km)";
			}else{
				li.textContent=joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(1)+" km)";
			}
		}else{
			li.textContent=joukkue.nimi.trim()+" ("+joukkueMuok.matka.toFixed(0)+" km)";
		}
		
		let vari=rainbow(joukkueet.length, i);
		li.style.backgroundColor=vari;
		li.setAttribute("draggable","true");
		li.joukkue= joukkue;
		ul.appendChild(li);
		i++;
	}
	div.appendChild(ul);
	
}

//Apufunktiot:
//Matkan muuttaminen kilometreiksi:
function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
	let R = 6371; // Radius of the earth in km
	let dLat = deg2rad(lat2-lat1);  // deg2rad below
	let dLon = deg2rad(lon2-lon1);
	let a =
	  Math.sin(dLat/2) * Math.sin(dLat/2) +
	  Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
	  Math.sin(dLon/2) * Math.sin(dLon/2)
	  ;
	let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
	let d = R * c; // Distance in km
	return d;
  }
  function deg2rad(deg) {
	return deg * (Math.PI/180);
  }

//Värien luonti:
function rainbow(numOfSteps, step) {
    // This function generates vibrant, "evenly spaced" colours (i.e. no clustering). This is ideal for creating easily distinguishable vibrant markers in Google Maps and other apps.
    // Adam Cole, 2011-Sept-14
    // HSV to RBG adapted from: http://mjijackson.com/2008/02/rgb-to-hsl-and-rgb-to-hsv-color-model-conversion-algorithms-in-javascript
    let r, g, b;
    let h = step / numOfSteps;
    let i = ~~(h * 6);
    let f = h * 6 - i;
    let q = 1 - f;
    switch(i % 6){
        case 0: r = 1; g = f; b = 0; break;
        case 1: r = q; g = 1; b = 0; break;
        case 2: r = 0; g = 1; b = f; break;
        case 3: r = 0; g = q; b = 1; break;
        case 4: r = f; g = 0; b = 1; break;
        case 5: r = 1; g = 0; b = q; break;
    }
    let c = "#" + ("00" + (~ ~(r * 255)).toString(16)).slice(-2) + ("00" + (~ ~(g * 255)).toString(16)).slice(-2) + ("00" + (~ ~(b * 255)).toString(16)).slice(-2);
    return (c);
}