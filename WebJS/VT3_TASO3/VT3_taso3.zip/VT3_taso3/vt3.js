"use strict";  // pidä tämä ensimmäisenä rivinä
//@ts-check

// Alustetaan data, joka on jokaisella sivun latauskerralla erilainen.
// tallennetaan data selaimen localStorageen, josta sitä käytetään seuraavilla
// sivun latauskerroilla. Datan voi resetoida lisäämällä sivun osoitteeseen
// ?reset=1
// jolloin uusi data ladataan palvelimelta
// Tätä saa tarvittaessa lisäviritellä
function alustus() {
     // luetaan sivun osoitteesta mahdollinen reset-parametri
     // https://developer.mozilla.org/en-US/docs/Web/API/URLSearchParams
     const params = new window.URLSearchParams(window.location.search);
     let reset = params.get("reset");
     let data;
     if ( !reset  ) {
       try {
          // luetaan vanha data localStoragesta ja muutetaan merkkijonosta tietorakenteeksi
          // https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage
          data = JSON.parse(localStorage.getItem("TIEA2120-vt3-2022s"));
       }
       catch(e) {
         console.log("vanhaa dataa ei ole tallennettu tai tallennusrakenne on rikki", data, e);
       }
       if (data) {
               console.log("Käytetään vanhaa dataa");
	       start( data );
               return;
           }
     }
     // poistetaan sivun osoitteesta ?reset=1, jotta ei koko ajan lataa uutta dataa
     // manipuloidaan samalla selaimen selainhistoriaa
     // https://developer.mozilla.org/en-US/docs/Web/API/History/pushState
     history.pushState({"foo":"bar"}, "VT3", window.location.href.replace("?reset="+reset, ""));
     // ladataan asynkronisesti uusi, jos reset =! null tai tallennettua dataa ei ole
     // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
	fetch('https://appro.mit.jyu.fi/cgi-bin/tiea2120/randomize_json.cgi')
	    .then(response => response.json())
	    .then(function(data) {
               console.log("Ladattiin uusi data", data);
               // tallennetaan data localStorageen. Täytyy muuttaa merkkijonoksi
	       // https://developer.mozilla.org/en-US/docs/Web/API/Storage/setItem
	       localStorage.setItem("TIEA2120-vt3-2022s", JSON.stringify(data));
 	       start( data );
	    }
  	    );
}

// oma sovelluskoodi voidaan sijoittaa tähän funktioon
function start(data) {
  // tänne oma koodi
  console.log(data);
  let sarjatData=data.sarjat;
  console.log(sarjatData);
  let sarjojenNimet=[];
  for(let sarja of sarjatData){
    sarjojenNimet.push(sarja.nimi);  
  }
  //Lajitellaan sarjojen nimet:
  sarjojenNimet.sort(lajittelu);
  //Luodaan sarja-radio vaihtoehdot lomakkeeseen:
  luodaanSarjat(sarjojenNimet, data);

  //Luodaan leimaustapa-checkboxit lomakkeeseen:
  let leimaustavatData=data.leimaustavat;
  let leimaustapaNimet=[];
  for(let leimaustapa of leimaustavatData){
      leimaustapaNimet.push(leimaustapa);
  }
  //Järjestetään leimaustavat ja luodaan ne lomakkeeseen:
  leimaustapaNimet.sort(lajittelu);
  luodaanLeimaustavat(leimaustapaNimet);


  //Luodaan lista joukkueista:
  luodaanLista(data);


  //Leimaustapa-lomakkeen käsittely:
  let leimaustapaLomake=document.forms.uusileimaus;
  let leimausInput=leimaustapaLomake.nimiLeimaus;
  let painonappi=leimaustapaLomake.tallennaLeimaus;
  painonappi.addEventListener("click",function(e){
    //Laitetaan suomenkieliseksi ilmoitus, jos klikataan suoraan painonappia:
    let leimausNimiInp=document.forms[1].elements[1];
    if(leimausNimiInp.value.trim()==""){
      leimausNimiInp.setCustomValidity("Kenttä ei saa olla tyhjä");
      leimausNimiInp.reportValidity();
    }
  });

  leimausInput.addEventListener("change",function(e){
    let leimausInp=e.target;
    let leimausNimi=e.target.value;
    leimausNimi=leimausNimi.toLowerCase().trim();
    //Jos kenttä tyhjä:
    if(leimausNimi==""){
      leimausInp.setCustomValidity("Kenttä ei saa olla tyhjä");
      leimausInp.reportValidity();
    }else{
      //Jos nimi ei vähintään 2 merkkiä:
      if(leimausInput.validity.patternMismatch){
        leimausInp.setCustomValidity("Nimen tulee olla vähintään 2 merkkiä pitkä");
        leimausInp.reportValidity();
      }else{
        //Tarkistetaan, että nimi on uniikki:
        let leimauksetData=data.leimaustavat;
        let leimausNimet=[];
        //Nimet taulukkoon vertailua varten:
        for(let leimaus of leimauksetData){
          let datanLeimaus=leimaus.toLowerCase().trim();
          leimausNimet.push(datanLeimaus);
        }
        if(leimausNimet.includes(leimausNimi)){
          leimausInp.setCustomValidity("Syötä uniikki nimi");
          leimausInp.reportValidity();
        }else{
          leimausInp.setCustomValidity("");
          leimausInp.reportValidity();
        }
      }
    }
  });
  //Leimaustapa-lomakkeen käsittelyä:
  leimaustapaLomake.addEventListener("submit",function(e){
    e.preventDefault();
    let hyvLeimausLomake=e.target;
    let hyvLeimaus=hyvLeimausLomake.nimiLeimaus;
    let vanhatLeimaukset=data.leimaustavat;
    vanhatLeimaukset.push(hyvLeimaus.value.trim());
    //Tallennetaan leimaus:
    localStorage.setItem("TIEA2120-vt3-2022s", JSON.stringify(data));

    //Poistetaan vanha leimaustavat joukkueet-lomakkeesta:
    let poistettavaInputit=document.forms[0].elements;
    let poistettavatArr=[];
    for(let poistettava of poistettavaInputit){
      if(poistettava.name=="leimaus"){
        poistettavatArr.push(poistettava);
      }
    }
    //Poistetaan haettu fieldset:
    let ekalabel=poistettavatArr[0].parentNode;
    let poistettuF=ekalabel.parentNode.remove();
    
    //Päivitetään leimaustavat:
    let uudetLeimaustavat=data.leimaustavat;
    let leimausNimet=[];
    for(let uusileimaus of uudetLeimaustavat){
      leimausNimet.push(uusileimaus);
    }
    leimausNimet.sort(lajittelu);
    luodaanLeimaustavat(leimausNimet);

    //Tyhjennetään lomake:
    hyvLeimausLomake.reset();

  });




  //Luodaan tarvittaessa lisää jäsenkenttiä:
  let jasenInputit=document.forms[0].jasenetF.elements;
  jasenInputit[0].addEventListener("input", uusiKentta);
  jasenInputit[1].addEventListener("input", uusiKentta);

  //Ylimääräisten jäsenkenttien luonti ja poisto:
  function uusiKentta(e){
    let tyhja=false;
    //Poistetaan ylimääräisiä jäsenkenttiä, jotka ovat tyhjiä:
    for(let i=jasenInputit.length-1; i>0; i--){
      let input =jasenInputit[i];
      //Huolehditaan, että jäsenkenttiä on lomakkeella aina vähintään 2 kpl:
      if(input.value.trim()=="" && tyhja&&jasenInputit.length>2){
        jasenInputit[i].parentNode.remove();
        
      }else if(jasenInputit[0].value.trim()==""&&jasenInputit.length>2){
        for(let j=jasenInputit.length-1; j>0;j--){
          let inputPoistettava=jasenInputit[j];
          if(inputPoistettava.value.trim()==""&&jasenInputit.length>2){
              inputPoistettava.parentNode.remove();
          }
        tyhja=true;
        }
      }
      if(input.value.trim()==""){
        tyhja=true;
      }
    }
    //Jos ei tyhjiä kenttiä, luodaan kenttiä:
    if(tyhja==false&&jasenInputit[0].value.trim()!==""){
      let labelJasen=document.createElement('label');
      labelJasen.textContent="Jäsen";
      let inputJasen=document.createElement('input');
      inputJasen.type="text";
      inputJasen.addEventListener("input", uusiKentta);
      let jasenFieldset=document.forms[0].jasenetF;
      labelJasen.appendChild(inputJasen);
      jasenFieldset.appendChild(labelJasen);
    }

    //Kenttien numerointi:
    for(let i=0; i<jasenInputit.length; i++){
      let labelVanhempi=jasenInputit[i].parentNode;
      labelVanhempi.firstChild.nodeValue="Jäsen "+(i+1);
    }
  }

  //Tarkistetaan, että uuden joukkueen nimi täyttää vaatimukset:
  let nimiLabel=document.forms[0].elements[0].children[1];
  let nimiInput=nimiLabel.children[0];
  nimiInput.addEventListener("change",function(e){ 
    //Uusi nimi:
    let input=e.target;
    let uusiNimi=input.value;
    uusiNimi=uusiNimi.toLowerCase().trim();
    //Jos kenttä tyhjä:
    if(uusiNimi==""){
      input.setCustomValidity("Kenttä ei saa olla tyhjä");
      input.reportValidity();
    } 
    else{
      //Jos nimi ei vähintään 2 merkkiä:
      if(input.validity.patternMismatch){
        input.setCustomValidity("Nimen tulee olla vähintään 2 merkkiä pitkä");
        input.reportValidity();
      }
      else{
        //Hyväksytään sama nimi, kun joukkuetta muokataan:
        if(muokataan==true&&muokattavaJoukkue.nimi.toLowerCase().trim()==input.value.toLowerCase().trim()){
          input.setCustomValidity("");
          input.reportValidity();
        }else{
          //Tarkistetaan, että syötetty nimi on uniikki:
          //Tarkistetaan, mitä joukkuenimiä jo olemassa:    
          let joukkueet=data.joukkueet;
          let joukkueNimi=[];
          //Laitetaan nimet taulukkoon vertailua varten:
          for(let joukkue of joukkueet){
              let vanhaNimi=joukkue.nimi;
              vanhaNimi=vanhaNimi.toLowerCase().trim();
              joukkueNimi.push(vanhaNimi);
          }
          if(joukkueNimi.includes(uusiNimi)){
                input.setCustomValidity("Syötä uniikki nimi");
                input.reportValidity();
          }
          else{
                input.setCustomValidity("");
                input.reportValidity();
          }
        }
      }
    }

  });


  //Otetaan jäsentiedot talteen:
  /*let jasenetVanhempi=document.forms[0].jasenetF.elements;
  let jasenetArr=[];
  for(let jasen of jasenetVanhempi){
    jasenetArr.push(jasen);
  }*/

  //Tehdään tarkistuksia, kun painonappia klikataan:
 let btn=document.forms[0].tallennus;
 btn.addEventListener("click", function(e){
  
  //Tarkistetaan, että jäseniä syötetty ainakin 2kpl:
  let jasenetV=document.forms[0].jasenetF.elements;
  let jasenetUusi=[];
  for(let jasen of jasenetV){
    jasenetUusi.push(jasen);
  }  

    let counter=0;
    let riittavasti=false;
    for(let jasen of jasenetUusi){
      //console.log("JÄSEN");
      //console.log(jasen.value);
      if(jasen.value.trim()!==""){
        counter=counter+1;
      }
    }
    let jasenYksi=jasenetUusi[0];
    //Jos täytettyjä kenttiä enemmän kuin 2 kpl niin kaikki ok:
    if(counter>=2){ 
      console.log("COUNTER");
      console.log(counter);
      jasenYksi.setCustomValidity("");
      jasenYksi.reportValidity();
      jasenetUusi[1].setCustomValidity("");
      jasenetUusi[1].reportValidity();
      riittavasti=true;
    }
    else{
      //Jos 1. ja 2.kenttä tyhjä
      if(jasenYksi.value.trim()==""&&jasenetUusi[1].value.trim()==""){
        jasenYksi.setCustomValidity("Syötä vähintään kaksi jäsentä");
        jasenYksi.reportValidity();
        riittavasti=false;
        //jos 1.kenttä tyhjä, tarkistetaan onko myös viimeinen kenttä tyhjä:
      }else if(jasenYksi.value.trim()==""&&jasenetUusi[jasenetUusi.length-1].value.trim()!=""){
        jasenYksi.setCustomValidity("Syötä vähintään kaksi jäsentä");
        jasenYksi.reportValidity();
        riittavasti=false;
      }
      //Jos vain 2.kenttä tyhjä:
      else if(jasenetUusi[1].value.trim()==""&&jasenYksi.value.trim()!=""){
        //Nollataan 1.kentän ilmoitukset, jotta virheilmoitus kohdistuu oikeaan kenttään
        jasenYksi.setCustomValidity("");
        jasenYksi.reportValidity();
        jasenetUusi[1].setCustomValidity("Syötä vähintään kaksi jäsentä");
        jasenetUusi[1].reportValidity();
        riittavasti=false;
      }else{ //1.kenttä voi olla tyhjä, jos syötetty kahteen muuhun kenttään jotain:
        jasenYksi.setCustomValidity("");
        jasenYksi.reportValidity();
        jasenetUusi[1].setCustomValidity("");
        jasenetUusi[1].reportValidity();
        riittavasti=true;
      }

    }
    //Jos jäseniä on syötetty vähintään 2, tarkistetaan, että ne eivät ole samat
    if(riittavasti==true){
      let counter;
      let jasenMaarat=new Map();
      for(let jasen of jasenetV){
        counter=0;
        let jasenValittu=jasen.value.toLowerCase().trim();
        for(let jasen of jasenetV){
          let jasenVertailu=jasen.value.toLowerCase().trim();
          if(jasenValittu==jasenVertailu){
            counter=counter+1;
          }
        }
        jasenMaarat.set(jasenValittu,counter);
      }
      console.log("TARKISTETAAN MAPPI JÄSENISTÄ");
      console.log(jasenMaarat);
      let duplikaatti;
      for(let [avain, arvo] of jasenMaarat.entries()){
        if(arvo>1){
          duplikaatti=avain;
        }
      }
      //Etsitään duplikaatti input:
      
      let jasenetInp=[];
      for(let jasen of jasenetV){
        jasenetInp.push(jasen);
      }
      let loytyi=0;
      let duplikaattiArr=[];
      for(let jasen of jasenetInp){
        if(duplikaatti==jasen.value.toLowerCase().trim()){
          loytyi=loytyi+1;
          duplikaattiArr.push(jasen);
        }
          //Laitetaan valitus, jos syötetty samanniminen:
          if(loytyi==2){
            jasen.setCustomValidity("Joukkueessa jo samanniminen jäsen");
            jasen.reportValidity();
            //loytyi=0;
          }else if(loytyi>2){
            jasen.setCustomValidity("Joukkueessa jo samanniminen jäsen");
            jasen.reportValidity();
          }
          else{
            jasen.setCustomValidity("");
            jasen.reportValidity();

          }
      }
    }
    //Laitetaan suomenkieliseksi ilmoitus, jos klikataan suoraan painonappia:
    let joukkueNimiInp=document.forms[0].elements[1];
    if(joukkueNimiInp.value.trim()==""){
      joukkueNimiInp.setCustomValidity("Kenttä ei saa olla tyhjä");
      joukkueNimiInp.reportValidity();
    }
    
    //Tarkistetaan, että valittu jokin leimaustapa
    let leimaustavat=document.forms[0].elements;
    let leimaustapaArr=[];
    for(let leimaustapaInput of leimaustavat){
      if(leimaustapaInput.type=="checkbox"){
        leimaustapaArr.push(leimaustapaInput);
      }
    }
    
    //Käydään kaikki chechboxit läpi:
    let valittu=false;
    for(let leimaustapa of leimaustapaArr){
      if(leimaustapa.checked==true){
        valittu=true;
      }
    }
    if(valittu==false){
      leimaustapaArr[0].setCustomValidity("Valitse leimaustapa");
      leimaustapaArr[0].reportValidity();
    }
    else{
      leimaustapaArr[0].setCustomValidity("");
      leimaustapaArr[0].reportValidity();
    }

});

//Jos klikataan listaan:
let lista=document.getElementById('listaosio').children;
let valittuUl=lista[0];
valittuUl.addEventListener("click", li_clicked);

let muokataan=false; //kertoo, onko joukkue valittu muokkaukseen
let muokattavaJoukkue;
function li_clicked(e){
  //Tarkastetaan, että on klikattu linkkiä:
  if(e.target!=e.currentTarget&&e.target.nodeName=='a'){
    //Siirretään klikatun joukkueen tiedot lomakkeeseen:
    let valittuJoukkue=e.target.joukkue;
    muokattavaJoukkue=e.target.joukkue;
    console.log("Joukkue valittu linkistä");
    console.log(valittuJoukkue);
    //Haetaan valitun joukkuen tietoja ja sijoitetaan ne lomakkeeseen:

    let lomakeMuok=document.forms[0].elements;
    //Asetetaan arvot, joita voi olla vain yksi:
    for(let input of lomakeMuok){
      if(input.name=="nimi"){
        input.value=valittuJoukkue.nimi;
        //Lisätty estämään turha valitus, jos välillä painelisi turhaan "tallenna"-nappia ja sitten yrittäisi muokata joukkueita:
        input.setCustomValidity("");
        input.reportValidity();
      }
      if(input.name=="sarja"){
        let valittuSarja=valittuJoukkue.sarja.toLowerCase().trim();
        let sarjaNyt=input.parentNode.textContent.toLowerCase().trim();
        if(valittuSarja==sarjaNyt){
          input.checked=true;
        }
      }
      //Siistii edellisen muokattavan joukkueen leimaukset pois:
      if(input.name=="leimaus"){
        input.checked=false;
      }
    }

    
    //Siistitään ylimääräiset inputkentät:
    let kentat=lomakeMuok.jasenetF.elements;
    let poistettavat=Array.from(kentat);
    if(poistettavat.length>2){
      for(let i=poistettavat.length-1; i>1; i--){
        let poistettavaKent=kentat[i];
        let labelPoistettava=poistettavaKent.parentNode;
        let poistoFieldset=labelPoistettava.parentNode;
        poistoFieldset.removeChild(labelPoistettava);
      }
    }
    
    //Etsitään leimaustavat:
    let valitutLeimaustavat=valittuJoukkue.leimaustapa;
    let dataLeimaukset=data.leimaustavat;
    let valitutLeimArr=[];
    for(let valittuLeimaus of valitutLeimaustavat){
      for(let leimaus of dataLeimaukset){
        let indeksi=dataLeimaukset.indexOf(leimaus);
        if(indeksi==parseInt(valittuLeimaus)){
          let loydettyNimi=leimaus.toLowerCase().trim();
          valitutLeimArr.push(loydettyNimi);
        }
      }
  }
  //Sijoitetaan lomakkeeseen leimaustavat:
  for(let leimaus of valitutLeimArr){
    for(let input of lomakeMuok){
      if(input.name.includes("leimaus")){
        let leimausNimi=input.parentNode.textContent.toLowerCase().trim();        
        if(leimausNimi==leimaus){
          input.checked=true;
        }
      }
    }
  }

    //Haetaan joukkueen jäsenien tiedot:
    let joukkueJasenet=valittuJoukkue.jasenet;
 
    let fieldsetJasenet=lomakeMuok.jasenetF;
    //Sijoitetaan jäsentiedot kenttiin ja tarvittaessa lisätään kenttien määrää:
    for(let jasen of joukkueJasenet){
      let indeksi=joukkueJasenet.indexOf(jasen);
      if(indeksi>1&&indeksi<joukkueJasenet.length){
        //Tässä luodaan lisää
          let labeluusi=document.createElement('label');
          labeluusi.textContent="Jäsen "+(indeksi+1);
          let inputuusi=document.createElement('input');
          inputuusi.type="text";
          inputuusi.value=jasen;
          labeluusi.appendChild(inputuusi);
          fieldsetJasenet.appendChild(labeluusi);
          inputuusi.addEventListener("input",uusiKentta);
      }
      else{
        jasenInputit[indeksi].value=jasen;
      }
    }
    //Lisätään uusi tyhjä kenttä loppuun:
    let labeluusi=document.createElement('label');
    labeluusi.textContent="Jäsen "+(joukkueJasenet.length+1);
    let inputuusi=document.createElement('input');
    inputuusi.type="text";
    inputuusi.value="";
    labeluusi.appendChild(inputuusi);
    fieldsetJasenet.appendChild(labeluusi);
    inputuusi.addEventListener("input",uusiKentta);
  

  //Tarkistetaan, että jäseniä syötetty ainakin 2kpl:
  let jasenetValittu=document.forms[0].jasenetF.elements;
  let jasenetMuokattu=[];
  for(let jasen of jasenetValittu){
    jasenetMuokattu.push(jasen);
  }   
    
    muokataan=true;
  }
}


 let lomake=document.forms[0];
 lomake.addEventListener("submit", function(e){
    e.preventDefault();
    //Lomake:
    let hyvLomake=e.target;
    //Luodaan uusi joukkue:
    let joukkueRakenne=data.joukkueet[0];
    console.log("JOUKKUE RAKENNE");
    console.log(joukkueRakenne);
    //Haetaan lomakkeelta joukkueen nimi:
    let nimiLab=hyvLomake.elements[0].children[1];
    let nimiInp=nimiLab.children[0];
    let hyvNimi=nimiInp.value.trim();
    //Haetaan kaikki sarjat:
    let sarjaJoukko=hyvLomake.elements; 
    let sarjatArr=[];
    for(let sarjaInput of sarjaJoukko){
      if(sarjaInput.type=="radio"){
        sarjatArr.push(sarjaInput);
      }
    }
    let hyvSarja;
    for(let sarja of sarjatArr){
      if(sarja.checked==true){
        let label=sarja.parentNode;
        hyvSarja=label.textContent.trim();
      }
    }

  //Etsitään valitun sarjan id sarjoista:
  /*let sarjat=data.sarjat;
  let valittuID;
  for(let sarja of sarjat){
    if(sarja['nimi']==hyvSarja){
      valittuID=sarja['id'];
    }
  }*/

  //Etsitään kaikki leimaustavat
  let inputteja=document.forms[0].elements;
  let leimausArr=[];
  for(let input of inputteja){
    if(input.name=="leimaus"){
      leimausArr.push(input);
    }
  }
  //Etsitään inputit, jotka ovat valittuja:
  let valitut=[];
  for(let leimaus of leimausArr){
    if(leimaus.checked==true){
      valitut.push(leimaus);
    }
  }
  //Haetaan datasta tieto leimaustavan id:stä
  let dataLeimaustavat=data.leimaustavat;
  let leimausID=[];
  for(let valittutapa of valitut){
    let label=valittutapa.parentNode;
    let teksti=label.textContent;
    for(let avain of dataLeimaustavat.keys()){
      if(teksti==dataLeimaustavat[avain]){
          leimausID.push(avain.toString());
      }
    }
  }

  //Kerätään hyväksytyt jäsenet:
  let jasenet=document.forms[0].jasenetF.elements;
  let jasenNimet=[];
  for(let jasen of jasenet){
    if(jasen.value.trim()!=""){
      jasenNimet.push(jasen.value.trim());
    }
  }
  if(muokataan==false){
    //Luodaan uusi joukkue:
    let joukkue={
      aika:"00:00:00",
      matka:"0",
      pisteet:"0",
      sarja:hyvSarja, //valittuID
      jasenet:jasenNimet,
      rastileimaukset:[],
      leimaustapa:leimausID,
      nimi:hyvNimi,
    };
    //Laitetaan liittäen dataan uusi joukkue:
    let kaikkiJoukkueet=data.joukkueet;
    kaikkiJoukkueet.push(joukkue);
  }else{
    //Muokataan vanhaa joukkuetta:
    //console.log("MUOKATAAN VANHAA JOUKKUETTA");
    //console.log(muokattavaJoukkue);
    muokattavaJoukkue.sarja=hyvSarja; //valittuID
    muokattavaJoukkue.jasenet=jasenNimet;
    muokattavaJoukkue.leimaustapa=leimausID;
    muokattavaJoukkue.nimi=hyvNimi;
    console.log("JOUKKUE MUOKATTU:");
    console.log(muokattavaJoukkue);
    muokataan=false;
  }
    
    //Dataa muokattu talletetaan localStorageen:
    localStorage.setItem("TIEA2120-vt3-2022s", JSON.stringify(data));
    console.log("uusi data");
    console.log(data);

    //Poistetaan vanha lista ja Luodaan sen tilalle uusi listaus:
    let poistettavaDiv=document.getElementById('listaosio');
    let poistettavaLista=poistettavaDiv.children[0];
    poistettavaLista.remove();
    luodaanLista(data);


    //tyhjennetään lomake:
    lomake.reset();
    //1.radiobutton vakiona valittuna:
    let vakioSarjaField=document.forms[0].elements[0].children.sarjaTiedot;
    let vakioSarjaInput=vakioSarjaField.children.sarjat.children[0].children[0];
    vakioSarjaInput.checked=true;

  //Poistetaan ylimääräiset jäsenkentät:
  let jasenetVan=document.forms[0].jasenetF.elements;
  let jasenetPoisto=[];
  for(let jasen of jasenetVan){
    jasenetPoisto.push(jasen);
  }
  if(jasenetPoisto.length>2){
    for(let j=jasenetPoisto.length-1; j>=2;j--){
      let input=jasenetPoisto[j];
      input.parentNode.remove();
    }
  } 
    //Jos klikataan listaan:
let lista=document.getElementById('listaosio').children;
let valittuUl=lista[0];
valittuUl.addEventListener("click", li_clicked);

    
 });

 



  // tallenna data sen mahdollisten muutosten jälkeen aina localStorageen. 
  // localStorage.setItem("TIEA2120-vt3-2022s", JSON.stringify(data));
  // kts ylempää mallia
  // varmista, että sovellus toimii oikein omien tallennusten jälkeenkin
  // eli näyttää sivun uudelleen lataamisen jälkeen edelliset lisäykset ja muutokset
  // resetoi rakenne tarvittaessa lisäämällä sivun osoitteen perään ?reset=1
  // esim. http://users.jyu.fi/~omatunnus/TIEA2120/vt2/pohja.xhtml?reset=1

}

window.addEventListener("load", alustus);

//Yleinen lajittelu:
function lajittelu(a,b){
  a=a.toLowerCase().trim();
  b=b.toLowerCase().trim();
  if(a<b){
    return -1;
  }
  if(a>b){
    return 1;
  }
  return 0;
}



function luodaanLeimaustavat(leimaustapaNimet){
  let lomakeTiedot=document.forms.joukkue;
  let fieldsetDiv=lomakeTiedot.elements[0].children.leimausTiedot;
  let indeksi=0;

  let div=document.createElement('div');
   div.id="leimaustavat";
    for(let nimi of leimaustapaNimet){
      indeksi=indeksi+1;
      let uusiLabel=document.createElement('label');
      uusiLabel.textContent=nimi;
      let uusiInput=document.createElement('input');
      uusiInput.type="checkbox";
      uusiInput.id="leimaus"+indeksi;
      uusiInput.name="leimaus";

      //Liitetään vanhempaan eli fieldset:
      uusiLabel.appendChild(uusiInput);
      div.appendChild(uusiLabel);
      fieldsetDiv.appendChild(div);


      
    }
  
}


function luodaanSarjat(sarjojenNimet){
    let lomakeTiedot=document.forms.joukkue;
    let fieldsetDiv=lomakeTiedot.elements[0].children.sarjaTiedot; //sarjat-label
    let indeksi=0;
    

   let div=document.createElement('div');
   div.id="sarjat";
    for(let nimi of sarjojenNimet){
      indeksi=indeksi+1;
      let uusiLabel=document.createElement('label');
      uusiLabel.textContent=nimi;
      let uusiInput=document.createElement('input');
      uusiInput.type="radio";
      uusiInput.id="sarja"+indeksi;
      uusiInput.name="sarja";
      //Ensimmäiseen sarja aina valittuna ensimmäisenä:
      if(sarjojenNimet.indexOf(nimi)==0){ 
        uusiInput.checked=true;
      }
      //Liitetään vanhempaan eli fieldsetSarjaan:
      uusiLabel.appendChild(uusiInput);
      div.appendChild(uusiLabel);
      fieldsetDiv.appendChild(div);


      
    }
}

function luodaanLista(data){
  let divLista=document.getElementById('listaosio');
  let joukkueet=data.joukkueet;
  
  //Luodaan taulukko joukkueista:
  let joukkueArr=Array.from(joukkueet);

  //Asetetaan sarjojen id ja nimi mappiin:
  let sarjat=data.sarjat;
  let sarjaTiedot=new Map();
  for(let sarja of sarjat){
    sarjaTiedot.set(sarja.id, sarja.nimi);
  }
  //Asetetaan mapin avulla joukkuetaulukkoon sarjannimi:
  for(let joukkue of joukkueArr){ 
    for(let avain of sarjaTiedot.keys()){
      if(parseInt(joukkue.sarja)==avain){
        joukkue.sarja=sarjaTiedot.get(avain);
      }
    }
  }
  //Lajitellaan joukkueet ensisijaisesti nimen perusteella:
  joukkueArr.sort(lajitteluJoukkueet);
  //Tehdään jokaisen joukkueen jäsenistä erilliset joukot:
  for(let joukkue of joukkueArr){  
    let jasenet=joukkue.jasenet;
    jasenet.sort(lajittelu);   
    joukkue.jasenet=jasenet; 
  }

  //Luodaan lista järjestetyistä joukkueista:
  //Luodaan pää ul-elementti:
  let ulVanhempi=document.createElement('ul');
  divLista.appendChild(ulVanhempi);
  //Luodaan jokaiselle joukkueelle omat tiedot omaan li-elementtiin:
  let indeksi=0;
  for(let joukkue of joukkueArr){
    let li=document.createElement('li');
    let strong=document.createElement('strong');
    let linkki=document.createElement('a');
    indeksi=indeksi+1;
    linkki.id="linkki"+indeksi;
    linkki.href="#joukkue";
    linkki.joukkue=joukkue;
    linkki.textContent=joukkue.nimi;
    strong.textContent=joukkue.sarja;
    li.appendChild(linkki);
    li.appendChild(strong);
    //Haetaan leimaustavat ja lisätään ne joukkueen nimen perään:
    let leimaustavat=data.leimaustavat;
    let valitutLeimaukset=[];
    for(let leima of joukkue.leimaustapa){
      for(let avain of leimaustavat.keys()){
         if(leima==avain){
          valitutLeimaukset.push(leimaustavat[avain]);
         }
      }
  }
    let span=document.createElement('span');
    span.textContent="("+valitutLeimaukset+")";
    li.appendChild(span);
    ulVanhempi.appendChild(li);
    //Luodaan sisäkkäinen lista jäsenistä:
    let ulJasen=document.createElement('ul');
    li.appendChild(ulJasen);
    if(typeof joukkue.jasenet!=="string"){
      for(let jasen of joukkue.jasenet){
        let liJasen=document.createElement('li');
        liJasen.textContent=jasen;
        ulJasen.appendChild(liJasen);
      }
    }else{
      let liYksiJasen=document.createElement('li');
      liYksiJasen.textContent=joukkue.jasenet;
      ulJasen.appendChild(liYksiJasen);
    }

  }

}
//Yleinen lajittelufunktio:
function lajitteluJoukkueet(a,b){
  let A=a.nimi;
  let B=b.nimi;
  A=A.toLowerCase().trim();
  B=B.toLowerCase().trim(); 
  //console.log(A+" ja "+B);
  if(A<B){
    return -1;
  }
  if(A>B){
    return 1;
  }
  return 0;
}