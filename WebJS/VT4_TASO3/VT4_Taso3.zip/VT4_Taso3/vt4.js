"use strict";
//@ts-check 
window.addEventListener("load",function(e){
    
    //Määritellään väripalkkien säätimen min ja max:
    let paksuusSaadin=document.getElementById('paksuus');
    paksuusSaadin.min=window.innerHeight/100;
    paksuusSaadin.max=window.innerHeight/2;
    paksuusSaadin.addEventListener("change",function(e){
        let svgPalkit=document.getElementsByClassName("svgPalkki");
        for(let svgPalkki of svgPalkit){
            svgPalkki.setAttribute("height",e.target.value);
        }
    });

    //Piilotetaan efektejä:
    let labelit=document.getElementById('elementit').children;
    let inputit=[];
    for(let label of labelit){
        for(let input of label.children){
            inputit.push(input);
        }
    }
    for(let input of inputit){
        input.addEventListener("change",function(e){
            let klikattuInput=e.target;
            let kaikkiEfektit=document.body.children;
            //Tuodaan näkyviin efekti:
            if(klikattuInput.checked==true){
                let nakyviin=klikattuInput.parentNode.textContent.trim();
                if(nakyviin=="Palkit"){
                    let svgt=document.getElementsByTagName('svg');
                    for(let svg of svgt){
                        svg.style.visibility="visible";
                    }
                }else if(nakyviin=="Skrolleri"){
                    /*Skrollerin käsittely jäänyt kesken*/
                }else if(nakyviin=="Pingviinit"){
                    let pingviinit=document.getElementsByClassName("pingu");
                    for(let pingu of pingviinit){
                        pingu.style.visibility="visible";
                    }
                }else{
                    let oikeatPollot=document.getElementsByClassName("oikealle");
                    let vasemmatPollot=document.getElementsByClassName("vasemmalle");
                    for(let pollo of oikeatPollot){
                        pollo.style.visibility="visible";
                    }
                    for(let pollo of vasemmatPollot){
                        pollo.style.visibility="visible";
                    }
                }
            //Piilotetaan efekti:
            }else{
                let piilotettava=klikattuInput.parentNode.textContent.trim();
                if(piilotettava=="Palkit"){
                    let svgt=document.getElementsByTagName('svg');
                    for(let svg of svgt){
                        svg.style.visibility="hidden";
                    }
                }else if(piilotettava=="Skrolleri"){
                    let skrollerit=document.getElementsByClassName('kalevala');
                    /*Jäänyt kesken skrollerin käsittely*/

                }else if(piilotettava=="Pingviinit"){
                    let pingviinit=document.getElementsByClassName("pingu");
                    for(let pingu of pingviinit){
                        pingu.style.visibility="hidden";
                    }
                }else{
                    let oikeatPollot=document.getElementsByClassName("oikealle");
                    let vasemmatPollot=document.getElementsByClassName("vasemmalle");
                    for(let pollo of oikeatPollot){
                        pollo.style.visibility="hidden";
                    }
                    for(let pollo of vasemmatPollot){
                        pollo.style.visibility="hidden";
                    }
                }
            }
        });
    }



    //Luodaan väriliukupalkit, svg-kuvina:
    let maara=10;
    let varit=["#ff0000", "#00ff00", "#0000ff", "#ff00ff", "#ffff00","#00ff00", "#00ffff", "#ffffff"];
    luodaanVaripalkit(maara,varit);

    //Luodaan pingviinejä:
    luodaanPingviini();
    let painonappi=document.getElementById('luo');
    painonappi.addEventListener("click",function(e){
        luodaanPingviini();
    });
    /*Pöllön käsittely tasolla 3 jäänyt kesken: */
    let osia=16;
    /*let osaSaadin=document.getElementById('osia');
    osaSaadin.min=1;
    osaSaadin.max=256;
    osaSaadin.addEventListener("change",function(e){
        osia=e.target.value;
        //luodaanPollo(osia);
        console.log(osia);
    });*/

    //Luodaan pöllö taso 1:
    luodaanPollo(osia);

    //Kalevala-teksti:
    luodaanTeksti();
    

    window.addEventListener("resize", mukautuminen);
});

/*Kalevala tekstiin liittyvät osat: kanvaasien luonti: */
function luodaanKanvaasi(){
    let kanvaasiTeksti=document.createElement('canvas');
    kanvaasiTeksti.setAttribute("class","kalevala");
    kanvaasiTeksti.width=307;//jotta teksti ei katkea 
    kanvaasiTeksti.height=window.innerHeight+30;
    document.body.appendChild(kanvaasiTeksti);
}

/*Kalevala tekstiin liittyvät osat: tekstin luonti: */
function luodaanTeksti(){
    luodaanKanvaasi();
    let kanvaasiTeksti= document.getElementsByClassName('kalevala')[0];   
    kanvaasiTeksti.id="kalevala1";
    let ctx=kanvaasiTeksti.getContext("2d");
    ctx.font="20px serif";
    ctx.fillStyle="white";
    let loppu= window.innerHeight+30;
    console.log("innerHeight");
    console.log(window.innerHeight/25);
    for(let i=25; i<loppu; i=i+30){ 
        ctx.fillText(kalevala(), 0, i);
    }

    luodaanKanvaasi();    
    let kanvaasiUusi= document.getElementsByClassName('kalevala')[1];
    kanvaasiUusi.style.animationDelay="6s";
    kanvaasiUusi.id="kalevala2";
    kanvaasiUusi.style.visibility="hidden";
    let ctx2=kanvaasiUusi.getContext("2d");
    ctx2.font="20px serif";
    ctx2.fillStyle="white";
    //let loppu2= window.innerHeight+30; //+30;//document.body.clientHeight+30;
    for(let i=25; i<loppu; i=i+30){
        ctx2.fillText(kalevala(), 0, i);

    }
    //kanvaasi näkyviin, kun animaatioalkaa
    kanvaasiUusi.addEventListener("animationstart", function(e){
        kanvaasiUusi.style.visibility="visible";
    });
    //Muokataan kanvaaseissa olevaa kalevala-tekstiä iteraatioiden mukaan:
    kanvaasiTeksti.addEventListener("animationiteration",muokkaaKa1);
    kanvaasiUusi.addEventListener("animationiteration",muokkaaKa2);
}  
/*Muokataan kanvaasien tekstiä: tyhjennetään kanvaasi ja luodaan uusi teksti tilalle: */
   function muokkaaKa2(e){
    let ctx=e.target.getContext("2d");
    ctx.clearRect(0,0,e.target.width,e.target.height);
            ctx.font="20px serif";
            ctx.fillStyle="white";
            let loppu=document.body.clientHeight+30;
            for(let i=25; i<=loppu; i=i+30){
                let teksti=kalevala();
                ctx.fillText(teksti, 0, i);
            }
  }
/*Muokataan kanvaasien tekstiä: tyhjennetään kanvaasi ja luodaan uusi teksti tilalle: */
function muokkaaKa1(e){
    let ctx=e.target.getContext("2d");
    ctx.clearRect(0,0,e.target.width,e.target.height);
            ctx.font="20px serif";
            ctx.fillStyle="white";
            let loppu=document.body.clientHeight+30;
            for(let i=25; i<=loppu; i=i+30){
                let teksti=kalevala();
                ctx.fillText(teksti, 0, i);
            }
}


    


//Jaetaan pöllö osiin ja piirretään se niiden avulla:
function luodaanPollo(osia){
    let pollomalli=document.getElementById('pollomalli');
    let lahdeY=0;
    let sijainti=window.innerHeight/2-pollomalli.height/2;
    let indeksi=0;
    for(let i=0; i<osia;i++){
        let kanvaasiPollo=document.createElement('canvas');
        let imgPollo=new Image();
        let korkeus=pollomalli.height;
        let leveys=pollomalli.width;
        imgPollo.alt="pollokuva"+i;
        kanvaasiPollo.height=Math.ceil(korkeus/osia);
        kanvaasiPollo.width=leveys;
        kanvaasiPollo.style.position="absolute";
        kanvaasiPollo.style.zIndex=3;/*2, jos pingviini halutaan pöllön päälle +muutos css-puolelle pingu-kohdan zindeksiin  */
      
        let ctx=kanvaasiPollo.getContext("2d");
       
        //Piirto, kun kuva latautunut:
        imgPollo.onload=function(){
        ctx.drawImage(imgPollo, 0, lahdeY, leveys, korkeus,0,0,leveys,korkeus);
            kanvaasiPollo.style.top=sijainti+"px"; 
            lahdeY=Math.ceil(lahdeY+(korkeus/osia));
            sijainti=sijainti+Math.ceil(korkeus/osia);
            if(indeksi%2==0){
                kanvaasiPollo.setAttribute("class","oikealle");
            }else{
                kanvaasiPollo.setAttribute("class","vasemmalle");
            }
            indeksi=indeksi+1;
            document.body.appendChild(kanvaasiPollo);
            window.addEventListener("resize", mukautuminen);
        }; 

        imgPollo.src= "http://appro.mit.jyu.fi/tiea2120/vt/vt4/owl.png";
        
    }
}
//Animaatioiden mukauttaminen näytön kokoon:
function mukautuminen(e){
    //Gradienttipalkit mukautuu näytön kokoon:
    let palkkisvgt=document.getElementsByTagName('svg');
    for(let palkki of palkkisvgt){
        palkki.style.animationName="";
        palkki.style.animationName="slide";
    }
    //Pingviinit mukautuu näytön kokoon:
    let pingviinit=document.getElementsByClassName('pingu');
    for(let pingu of pingviinit){
        pingu.style.animationName="";
        pingu.style.animationName="ruutu";
    }

    //Pöllö mukautuu näytön kokoon:
    let polloVas=document.getElementsByClassName('vasemmalle');
    let polloOik=document.getElementsByClassName('oikealle');
    /*if(window.innerWidth<=564){
        for(let pollo of polloVas){
            pollo.style.animationName="";
        }
        for(let pollo of polloOik){
            pollo.style.animationName="";
        }
    }*/   
    for(let pollo of polloVas){
        pollo.style.animationName="";
        pollo.style.animationName="vasemmalle";
    }
    for(let pollo of polloOik){
        pollo.style.animationName="";
        pollo.style.animationName="oikealle";
    }

    //Kalevala-teksti mukautuu näytön kokoon:
    let skrollerit=document.getElementsByClassName('kalevala');
    for(let skrolleri of skrollerit){
        skrolleri.style.animationName="";
        skrolleri.style.animationName="ylos";
    }
}

//Pingviinin luonti:
function luodaanPingviini(){
    let img=document.createElement('img');
    img.setAttribute("class","pingu");
    img.src="https://appro.mit.jyu.fi/tiea2120/vt/vt4/penguin.png";
    img.alt="Pingu";
    let svgEka=document.getElementsByTagName('svg')[0];
    document.body.insertBefore(img,document.body.svgEka);
}
function luodaanVaripalkit(maara, varit){
    
    for(let i=0; i<maara; i++){
    let svgPalkki = document.createElementNS("http://www.w3.org/2000/svg","svg");
    svgPalkki.setAttribute("class","svgPalkki");
    svgPalkki.setAttribute("xmlns","http://www.w3.org/2000/svg");
    svgPalkki.setAttribute("version","1.1");
    svgPalkki.setAttribute("width","250%"); 
    svgPalkki.setAttribute("height", "60");
    //Viive:
    svgPalkki.style.animationDelay=0.25*i+"s";
    //Pidetään palkit piilossa kunnes animaatio alkaa:
    svgPalkki.style.visibility="hidden";
    svgPalkki.addEventListener("animationstart",function(e){
        svgPalkki.style.visibility="visible";
    });

    if(i==0){
        //Luodaan gradientti 1: violetti, Taso1
    let defs = document.createElementNS("http://www.w3.org/2000/svg","defs");
    let gradienttiLinear=document.createElementNS("http://www.w3.org/2000/svg","linearGradient");
    gradienttiLinear.setAttribute("id", "Gradientti1");
    gradienttiLinear.setAttribute("x1", "0");
    gradienttiLinear.setAttribute("x2", "0");
    gradienttiLinear.setAttribute("y1", "0");
    gradienttiLinear.setAttribute("y2", "1");
    let stoppi1=document.createElementNS("http://www.w3.org/2000/svg","stop");
    stoppi1.setAttribute("class","stoppi1");
    stoppi1.setAttribute("offset","0%");
    let stoppi2=document.createElementNS("http://www.w3.org/2000/svg","stop");
    stoppi2.setAttribute("class","stoppi2");
    stoppi2.setAttribute("offset","50%");
    let stoppi3=document.createElementNS("http://www.w3.org/2000/svg","stop");
    stoppi3.setAttribute("class","stoppi3");
    stoppi3.setAttribute("offset","100%");
        //Luodaan gradientti 2: keltainen, Taso1
    let gradienttiLinear2=document.createElementNS("http://www.w3.org/2000/svg","linearGradient");
    gradienttiLinear2.setAttribute("id", "Gradientti2");
    gradienttiLinear2.setAttribute("x1", "0");
    gradienttiLinear2.setAttribute("x2", "0");
    gradienttiLinear2.setAttribute("y1", "0");
    gradienttiLinear2.setAttribute("y2", "1");
    let stop1=document.createElementNS("http://www.w3.org/2000/svg","stop");
    stop1.setAttribute("class","stop1");
    stop1.setAttribute("offset","0%");
    let stop2=document.createElementNS("http://www.w3.org/2000/svg","stop");
    stop2.setAttribute("class","stop2");
    stop2.setAttribute("offset","50%");
    let stop3=document.createElementNS("http://www.w3.org/2000/svg","stop");
    stop3.setAttribute("class","stop3");
    stop3.setAttribute("offset","100%");
    gradienttiLinear2.appendChild(stop1);
    gradienttiLinear2.appendChild(stop2);
    gradienttiLinear2.appendChild(stop3);
    defs.appendChild(gradienttiLinear2);
   
    gradienttiLinear.appendChild(stoppi1);
    gradienttiLinear.appendChild(stoppi2);
    gradienttiLinear.appendChild(stoppi3);
    defs.appendChild(gradienttiLinear);
    svgPalkki.appendChild(defs);
   } 
   //Luodaan väripalkit:
    let palkki = document.createElementNS("http://www.w3.org/2000/svg","rect");
    palkki.setAttribute("x","0"); //0
    palkki.setAttribute("y","0"); //0
    palkki.setAttribute("width","100%");
    palkki.setAttribute("height","80%"); 
    palkki.style.fill="url(#Gradientti1)";
    
    svgPalkki.appendChild(palkki);
    document.body.insertBefore(svgPalkki,document.body.lastChild);

    //Taso 3: Muutetaan värejä iteraatioiden mukaisesti:
    let iteraatio=0;
    svgPalkki.addEventListener("animationiteration", function(e){
        let palkkiVal=svgPalkki.children[svgPalkki.children.length-1];
        let gradientti1=document.getElementsByClassName('stoppi2')[0];
        let variMaara=varit.length-1;
        //Käydään läpi kaikki värit:
        for(let [i,vari] of varit.entries()){
            if(iteraatio==i){
                gradientti1.style.stopColor=vari;
                palkkiVal.style.fill="url(#Gradientti1)";
            }
        }
        if(iteraatio<variMaara){
            iteraatio++;
        }else if(iteraatio==variMaara){
            iteraatio=0;
        }
          
        
    });
    //Taso 1: Muutetaan värejä iteraatioiden mukaisesti: 
    //Vaihdetaan palkkienväri 2.iteraatio kerralla:    
    /*let iteraatio=1;
    svgPalkki.addEventListener("animationiteration", function(e){
        let palkkiVal=svgPalkki.children[svgPalkki.children.length-1];
        //Keltainen:
        if(iteraatio%2!=0){
            palkkiVal.style.fill="url(#Gradientti2)";
            //Violetti:
        }else{
            palkkiVal.style.fill="url(#Gradientti1)";

        }   
        iteraatio++;
    });*/

    
    
    
    


    }   
    
}

